<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container\Address;

use Magecheckout\SecureCheckout\Block\Container\Address;

class Shipping extends Address
{
    /**
     * @return bool
     */
    public function canShow()
    {
        return !$this->_helperConfig->disableShippingAddress() && !$this->getOnePage()->getQuote()->isVirtual();
    }

}