<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container;

use Magecheckout\SecureCheckout\Block\Context;
use Magecheckout\SecureCheckout\Block\Container;
use Magecheckout\SecureCheckout\Helper\Checkout\Payment as CheckoutPayment;

class Form extends Container
{
    protected $_checkoutPayment;

    public function __construct(
        Context $context,
        CheckoutPayment $checkoutPayment
    ) {
        parent::__construct($context);
        $this->_checkoutPayment = $checkoutPayment;

    }

    /**
     * @return array
     */
    public function getCheckoutConfig()
    {
        return $this->_configProvider->getConfig();
    }

    public function getSecureCheckoutConfig()
    {
        return array(
            'savePaymentUrl'       => $this->getSavePaymentUrl(),
            'defaultPaymentMethod' => $this->_checkoutPayment->getDefaultPaymentMethod()
        );
    }

    /**
     * @return mixed
     */
    public function showGrandTotal()
    {
        return $this->getHelperConfig()->showGrandTotal();
    }

    /**
     * @return string
     */
    public function getBlockSection()
    {
        return $this->_jsonHelper->jsonEncode($this->_helperBlock->getBlocksSection());
    }

    public function getPlaceOrderUrl()
    {
        return $this->getUrl('onestepcheckout/ajax/saveOrder', ['_secure' => $this->isSecure()]);
    }

    public function getCheckoutSuccessUrl()
    {
        return $this->getUrl('checkout/onepage/success', ['_secure' => $this->isSecure()]);
    }
}