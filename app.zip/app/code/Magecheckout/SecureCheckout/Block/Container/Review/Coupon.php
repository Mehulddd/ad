<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container\Review;

use Magecheckout\SecureCheckout\Block\Container\Review;

class Coupon extends Review
{
    
    public function getCouponCode()
    {
        return $this->getQuote()->getCouponCode();
    }

    /**
     * @return mixed
     */
    public function getApplyCouponAjaxUrl()
    {
        return $this->getUrl('onestepcheckout/ajax/saveCoupon', ['_secure' => $this->isSecure()]);
    }

    /**
     * enable gift message or not
     *
     */
    public function canShow()
    {
        return $this->getHelperConfig()->isCoupon();
    }

    /**
     * @return mixed
     */
    public function getShowApplyButton()
    {
        return $this->getHelperConfig()->isApplyCouponButton();
    }

}