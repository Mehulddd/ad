<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container\Review;

use Magecheckout\SecureCheckout\Block\Container\Review;
use Magecheckout\SecureCheckout\Helper\Checkout\Review\Giftmessage as MessageHelper;
use Magecheckout\SecureCheckout\Model\System\Config\Source\Giftmessage as SourceGiftmessage;
use Magecheckout\SecureCheckout\Block\Context;

class Giftmessage extends Review
{
    /**
     * @var messageHelper
     */
    protected $_messageHelper;

    public function __construct(
        Context $context,
        array $data = [],
        MessageHelper $messageHelper
    ) {
        parent::__construct($context, $data);

        $this->_messageHelper = $messageHelper;

    }

    /**
     * enable gift message or not
     *
     */
    public function canShow()
    {
        $reviewSection = SourceGiftmessage::REVIEW_SECTION;

        return $this->_messageHelper->isEnabled() == $reviewSection;
    }

    /**
     * @return string
     */
    public function getGiftMessageUrl()
    {
        return $this->getUrl('onestepcheckout/ajax/saveGiftMessage', ['_secure' => $this->isSecure()]);
    }

    /**
     * @return GiftmessHelper|MessageHelper
     */
    public function getMessageHelper()
    {
        return $this->_messageHelper;
    }

}