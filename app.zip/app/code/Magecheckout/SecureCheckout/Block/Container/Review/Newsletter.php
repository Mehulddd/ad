<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container\Review;

use Magecheckout\SecureCheckout\Block\Container\Review;

class Newsletter extends Review
{

    public function canShow()
    {
        if ($this->isCustomerLoggedIn()) {
            $email = $this->getCustomer()->getEmail();
            if ($this->getHelperData()->isSubscribed($email)) {
                return false;
            }
        }

        return $this->getHelperConfig()->isNewsletter();
    }

    public function getIsSubscribed()
    {
        $data   = $this->getFormData();
        $isSubs = isset($data['is_subscribed']) ? $data['is_subscribed'] : $this->getHelperConfig()->isSubscribedByDefault();

        return $isSubs;
    }

}