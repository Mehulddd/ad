<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Container\Shipping;

use Magecheckout\SecureCheckout\Block\Container;
use Magecheckout\SecureCheckout\Block\Context;
use Magento\Tax\Helper\Data as TaxHelper;

class Method extends Container
{
    protected $_rates = null;
    protected $_address = null;
    private $_taxHelper;

    public function __construct(Context $context,
                                TaxHelper $taxHelper,
                                array $data = [])
    {
        parent::__construct($context, $data);
        $this->_taxHelper = $taxHelper;
    }

    /**
     * get Shipping Address From Quote
     *
     * @return Address|null
     */
    public function getShippingAddress()
    {
        if (empty($this->_address)) {
            $this->_address = $this->getQuote()->getShippingAddress();
        }

        return $this->_address;
    }

    public function getShippingPrice($price, $flag)
    {
        return $this->getHelperData()->formatPrice($this->_taxHelper->getShippingPrice($price, $flag, $this->getShippingAddress()), true);
    }

    public function getSaveShippingMethodUrl()
    {
        return $this->getUrl('onestepcheckout/ajax/saveShippingMethod', ['_secure' => $this->isSecure()]);
    }

}