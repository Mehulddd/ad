<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category   Magecheckout
 * @package    Magecheckout_SecureCheckout
 * @version    3.0.0
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Generator;

use Magecheckout\SecureCheckout\Helper\Config;
use Magento\Framework\App\ObjectManager;
use Magento\Framework\View\Element\Template;
use Magecheckout\SecureCheckout\Block\Context;

class Css extends Template
{
    /**
     * @var Config
     */
    protected $_helperConfig;

    protected $_objectManager;

    public function __construct(Context $context,
                                array $data = []
    ) {
        parent::__construct($context, $data);
        $this->_helperConfig  = $context->getHelperConfig();
        $this->_objectManager = $context->getObjectManager();

    }

    public function getFieldColspan($attribute_code)
    {
        return 2;
    }

    public function getHelperConfig()
    {
        return $this->_helperConfig;
    }
}