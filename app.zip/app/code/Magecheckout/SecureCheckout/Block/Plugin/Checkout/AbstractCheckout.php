<?php

/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */
namespace Magecheckout\SecureCheckout\Block\Plugin\Checkout;

use Magento\Framework\View\Element\Template\Context;
use Magento\Framework\View\Element\Template;
use Magecheckout\SecureCheckout\Helper\Config as HelperConfig;

class AbstractCheckout extends Template
{
    public function __construct(
        Context $context,
        HelperConfig $systemConfig,
        array $data = []

    ) {
        $this->_systemConfig = $systemConfig;
        parent::__construct($context, $data);

    }

    /**
     * Get checkout url
     *
     * @return string
     */
    protected function _getCheckoutUrl()
    {
        return $this->_systemConfig->isEnabled() ?
            $this->getUrl('onestepcheckout') : $this->getUrl('checkout');
    }
}