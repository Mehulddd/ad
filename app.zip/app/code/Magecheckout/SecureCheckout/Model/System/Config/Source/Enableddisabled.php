<?php
/**
* Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (http://www.magecheckout.com/)
 * @license     http://wiki.magecheckout.com/general/license.html
 */


namespace Magecheckout\SecureCheckout\Model\System\Config\Source;

class Enableddisabled
{
    const DISABLED_CODE = 0;
    const ENABLED_CODE  = 1;
    const DISABLED_LABEL = 'Disabled';
    const ENABLED_LABEL  = 'Enabled';

    /**
     * Options getter
     *
     * @return array
     */
    public function toOptionArray()
    {
        return [
            [
                'value' => self::ENABLED_CODE,
                'label' => __(self::ENABLED_LABEL),
            ],
            [
                'value' => self::DISABLED_CODE,
                'label' => __(self::DISABLED_LABEL),
            ],
        ];
    }

    /**
     * Get options in "key-value" format
     *
     * @return array
     */
    public function toArray()
    {
        return [
            self::ENABLED_CODE  => __(self::ENABLED_LABEL),
            self::DISABLED_CODE => __(self::DISABLED_LABEL),
        ];
    }
}