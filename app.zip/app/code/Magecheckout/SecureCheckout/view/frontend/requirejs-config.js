/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */

var config = {
    map: {
        '*': {
            'magecheckout/securecheckout/jquery/popup': 'Magecheckout_SecureCheckout/js/jquery/popup/jquery.magnific-popup.min',
            'magecheckout/securecheckout': 'Magecheckout_SecureCheckout/js/securecheckout',
            'magecheckout/securecheckout/form': 'Magecheckout_SecureCheckout/js/securecheckout/form',
            'magecheckout/securecheckout/popup': 'Magecheckout_SecureCheckout/js/securecheckout/popup',
            'magecheckout/securecheckout/auth': 'Magecheckout_SecureCheckout/js/securecheckout/auth',
            'magecheckout/securecheckout/address': 'Magecheckout_SecureCheckout/js/securecheckout/address',
            'magecheckout/securecheckout/address/region-updater': 'Magecheckout_SecureCheckout/js/securecheckout/address/region-updater',
            'magecheckout/securecheckout/address/google-auto-complete': 'Magecheckout_SecureCheckout/js/securecheckout/address/google-auto-complete',
            'magecheckout/securecheckout/shipping/method': 'Magecheckout_SecureCheckout/js/securecheckout/shipping/method',
            'magecheckout/securecheckout/payment/method': 'Magecheckout_SecureCheckout/js/securecheckout/payment/method',
            'magecheckout/securecheckout/payment/information': 'Magecheckout_SecureCheckout/js/action/get-payment-information',
            'magecheckout/securecheckout/review/cart': 'Magecheckout_SecureCheckout/js/securecheckout/review/cart',
            'magecheckout/securecheckout/review/coupon': 'Magecheckout_SecureCheckout/js/securecheckout/review/coupon',
            'magecheckout/securecheckout/review/comment': 'Magecheckout_SecureCheckout/js/securecheckout/review/comment',
            'magecheckout/securecheckout/review/giftmessage': 'Magecheckout_SecureCheckout/js/securecheckout/review/giftmessage',
            'magecheckout/securecheckout/review/giftwrap': 'Magecheckout_SecureCheckout/js/securecheckout/review/giftwrap',
            'magecheckout/securecheckout/review/term': 'Magecheckout_SecureCheckout/js/securecheckout/review/term',
        }
    }

};
