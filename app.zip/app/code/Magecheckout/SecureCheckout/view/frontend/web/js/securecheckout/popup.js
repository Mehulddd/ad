/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (https://magecheckout.com/)
 * @license     https://magecheckout.com/license-agreement/
 */
define(["jquery", "magecheckout/securecheckout/jquery/popup", "prototype"], function (jq) {
    /*Secure Checkout Popup*/
    var MagecheckoutSecureCheckoutPopup = Class.create();
    MagecheckoutSecureCheckoutPopup.prototype = {
        initialize: function (config) {
            this.selector = jq(config.selector);
            this.delegate = config.delegate ? config.delegate : 'a';
            this.initPopup();

        },
        initPopup: function () {
            this.selector.magnificPopup({
                delegate: this.delegate,
                removalDelay: 500, //delay removal by X to allow out-animation
                callbacks: {
                    beforeOpen: function () {
                        this.st.mainClass = this.st.el.attr('data-effect');
                        MagecheckoutSecureCheckout.loginPopup = true;
                    },
                    beforeClose: function () {
                        MagecheckoutSecureCheckout.loginPopup = false;
                    }
                },
                midClick: true // allow opening popup on middle mouse click. Always set it to true if you don't provide alternative source.
            }).instance;
        },
        hidePopup: function () {
            jq.magnificPopup.close();
        }

    };
    return MagecheckoutSecureCheckoutPopup;
});


