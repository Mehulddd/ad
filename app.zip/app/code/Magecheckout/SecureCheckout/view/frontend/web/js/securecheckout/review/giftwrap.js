/**
 * Magecheckout
 *
 * NOTICE OF LICENSE
 *
 * This source file is subject to the Magecheckout.com license that is
 * available through the world-wide-web at this URL:
 * http://wiki.magecheckout.com/general/license.html
 *
 * DISCLAIMER
 *
 * Do not edit or add to this file if you wish to upgrade this extension to newer
 * version in the future.
 *
 * @category    Magecheckout
 * @package     Magecheckout_SecureCheckout
 * @copyright   Copyright (c) 2015 Magecheckout (https://magecheckout.com/)
 * @license     https://magecheckout.com/license-agreement/
 */
define(["prototype"], function () {
    /* Gift Wrap Class */
    MagecheckoutSecureCheckoutReviewGiftwrap = Class.create();
    MagecheckoutSecureCheckoutReviewGiftwrap.prototype = {
        initialize: function (config) {
            this.useGiftWrapCheckbox = $$(config.useGiftWrapCheckbox).first();
            this.addGiftWrapUrl = config.addGiftWrapUrl;
            this.initObserver();
        },
        initObserver: function () {
            if (this.useGiftWrapCheckbox) {
                this.useGiftWrapCheckbox.observe('change', this.applyGiftWrap.bind(this))
            }
        },
        applyGiftWrap: function () {
            var requestOptions = {
                method: 'post',
                parameters: {
                    is_used_giftwrap: this.useGiftWrapCheckbox.getValue()
                }
            };
            MagecheckoutSecureCheckout.Request(this.addGiftWrapUrl, requestOptions);
        }
    };
    return MagecheckoutSecureCheckoutReviewGiftwrap;
});


