/**
 * Copyright © 2015 Magento. All rights reserved.
 * See COPYING.txt for license details.
 */
/*browser:true*/
/*global define*/
define(
    [
        'Magecheckout_SecureCheckout/js/view/payment/method-renderer/paypal-express-abstract'
    ],
    function (Component) {
        'use strict';

        return Component.extend({
            defaults: {
                template: 'Magecheckout_SecureCheckout/payment/paypal-express'
            }
        });
    }
);
