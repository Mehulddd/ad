<?php

namespace Pinamondo\Bannerslider\Api\Data;

interface PostInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const POST_ID               = 'post_id';
    const NAME                  = 'name';
    const DESCRIPTION           = 'description';
    const ADVANCED_CSS          = 'advanced_css';
    const CREATED_AT            = 'created_at';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get Name
     *
     * @return string
     */
    public function getName();

    /**
     * Get Description
     *
     * @return string|null
     */
    public function getDescription();

    /**
     * Get Advanced Css
     *
     * @return string|null
     */
    public function getAdvancedCss();

    /**
     * Get Created At
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set ID
     *
     * @param int $id
     * @return \Pinamondo\Bannerslider\Api\Data\PostInterface
     */
    public function setId($id);

    /**
     * Set Name
     *
     * @param string $name
     * @return \Pinamondo\Bannerslider\Api\Data\PostInterface
     */
    public function setName($name);

    /**
     * Set Description
     *
     * @param string $text1
     * @return \Pinamondo\Bannerslider\Api\Data\PostInterface
     */
    public function setDescription($description);

    /**
     * Set Advanced Css
     *
     * @param string $advancedCss
     * @return \Pinamondo\Bannerslider\Api\Data\PostInterface
     */
    public function setAdvancedCss($advancedCss);

    /**
     * Set Created At
     *
     * @param string $createdAt
     * @return \Pinamondo\Bannerslider\Api\Data\PostInterface
     */
    public function setCreatedAt($createdAt);

}