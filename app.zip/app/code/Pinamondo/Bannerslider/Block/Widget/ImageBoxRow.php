<?php
namespace Pinamondo\Bannerslider\Block\Widget;

class ImageBoxRow extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    protected function _construct()
    {
        parent::_construct();

        $this->setTemplate('widget/image-box-row.phtml');
    }
}