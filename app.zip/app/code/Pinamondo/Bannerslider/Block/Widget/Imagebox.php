<?php
namespace Pinamondo\Bannerslider\Block\Widget;

class Imagebox extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    protected function _construct()
    {
        parent::_construct();

        $om = \Magento\Framework\App\ObjectManager::getInstance();

        $connection = $om->create('\Magento\Framework\App\ResourceConnection')
            ->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tblSalesOrder = $connection->getTableName('pinamondo_bannerslider');
        $result = $connection->fetchRow('SELECT advanced_css,description FROM `'.$tblSalesOrder.'` WHERE post_id='.$this->getData('bannersliderid'));

        $this->setData('description', $result['description']);
        $this->setData('css', preg_replace("%'%", "\\'", $result['advanced_css']));

        $this->setTemplate('widget/image-box.phtml');
    }
}