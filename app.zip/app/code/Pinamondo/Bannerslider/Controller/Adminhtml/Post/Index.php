<?php

namespace Pinamondo\Bannerslider\Controller\Adminhtml\Post;

use Magento\Backend\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Index extends \Magento\Backend\App\Action
{
    const ADMIN_RESOURCE = 'Pinamondo_Bannerslider::post';

    /**
     * @var PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Context $context
     * @param PageFactory $resultPageFactory
     */
    public function __construct(
        Context $context,
        PageFactory $resultPageFactory
    ) {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    /**
     * Index action
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    public function execute()
    {
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Pinamondo_Bannerslider::post');
        $resultPage->addBreadcrumb(__('Bannerslider Posts'), __('Bannerslider Posts'));
        $resultPage->addBreadcrumb(__('Manage Bannerslider Posts'), __('Manage Bannerslider Posts'));
        $resultPage->getConfig()->getTitle()->prepend(__('Bannerslider Posts'));

        return $resultPage;
    }
}