<?php

namespace Pinamondo\Bannerslider\Model;

use Magento\Framework\Exception\LocalizedException as CoreException;

class Bannerslider extends \Magento\Framework\Model\AbstractModel
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Pinamondo\Bannerslider\Model\ResourceModel\Bannerslider');
    }
}