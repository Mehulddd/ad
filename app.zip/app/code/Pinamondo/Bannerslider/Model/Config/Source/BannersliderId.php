<?php

namespace Pinamondo\Bannerslider\Model\Config\Source;

class BannersliderId implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        $om = \Magento\Framework\App\ObjectManager::getInstance();

        $connection = $om->create('\Magento\Framework\App\ResourceConnection')
            ->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tblSalesOrder = $connection->getTableName('pinamondo_bannerslider');
        $results = $connection->fetchAll('SELECT post_id, name FROM `'.$tblSalesOrder.'`');

        foreach($results as $result) {
            $fl['label'] = __($result['name']);
            $fl['value'] = $result['post_id'];
            $list[] = $fl;
        }

        return $list;
    }
}