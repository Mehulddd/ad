<?php
namespace Pinamondo\Bannerslider\Model\Config\Source;

use Magento\Framework\App\Filesystem\DirectoryList;

class BoxType implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        return [
            ['value' => 'full', 'label' => __('Full width')],
            ['value' => '1-from-2', 'label' => __('Half width')],
            ['value' => '1-from-3', 'label' => __('1/3 width')],
            ['value' => '2-from-3', 'label' => __('2/3 width')],
        ];
    }
}