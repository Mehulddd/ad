<?php
namespace Pinamondo\Bannerslider\Model\Config\Source;

use Magento\Framework\App\Filesystem\DirectoryList;

class OverlayImageUrl implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * @param string $relativeMediaPath
     * @return string
     */
    protected function getAbsoluteMediaPath($relativeMediaPath) {
        /** @var \Magento\Framework\App\ObjectManager $om */
        $om = \Magento\Framework\App\ObjectManager::getInstance();
        /** @var \Magento\Framework\Filesystem $filesystem */
        $filesystem = $om->get('Magento\Framework\Filesystem');
        /** @var \Magento\Framework\Filesystem\Directory\ReadInterface|\Magento\Framework\Filesystem\Directory\Read $reader */
        $reader = $filesystem->getDirectoryRead(\Magento\Framework\App\Filesystem\DirectoryList::MEDIA);
        return $reader->getAbsolutePath($relativeMediaPath);
    }

    public function toOptionArray()
    {
        $list = array('' => '-- Please Select --');
        $mediaPath = $this->getAbsoluteMediaPath('wysiwyg/');

        $objects = new \RecursiveIteratorIterator(
            new \RecursiveDirectoryIterator($mediaPath),
            \RecursiveIteratorIterator::SELF_FIRST);
        foreach($objects as $fileInfo) {
            if($fileInfo->isDir()) continue;
            if (strpos($fileInfo->getRealpath(), '.thumbs')!==false) continue;

            $theFilename = str_replace($mediaPath, '', $fileInfo->getRealpath());
            $fl['label'] = __($theFilename);
            $fl['value'] = 'pub/media/wysiwyg/'.$theFilename;
            $list[] = $fl;
        }

        return $list;

    }
}