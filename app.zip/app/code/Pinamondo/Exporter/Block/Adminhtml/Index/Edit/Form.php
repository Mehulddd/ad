<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Pinamondo\Exporter\Block\Adminhtml\Index\Edit;

class Form extends \Magento\Backend\Block\Widget\Form\Generic
{
    
    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('exporter_form');
        $this->setTitle(__('Exporter Information'));
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Ashsmith\Blog\Model\Post $model */
        $model = $this->_coreRegistry->registry('exporter_data');
        $attributes = $this->_coreRegistry->registry('exporter_attributes');
        $model_attributes = $this->_coreRegistry->registry('exporter_db_attributes');
        $model_custom_attributes = $this->_coreRegistry->registry('exporter_db_custom_attributes');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $form->setHtmlIdPrefix('post_');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('General Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $fieldset->addField(
            'exporter_name',
            'text',
            ['name' => 'exporter_name', 'label' => __('Name'), 'title' => __('Name'), 'required' => true]
        );

        $form->setValues($model->getData());
        
        foreach ($attributes as $attribute) {
            if (empty($attribute->getFrontendLabel()))
                continue;
            if (isset($model_attributes[$attribute->getAttributeCode()])) {
                $fieldset->addField(
                    'attribute_alias_'.$attribute->getAttributeCode(),
                    'text',
                    [
                        'name' => 'attribute_alias['.$attribute->getAttributeCode().']',
                        'label' => __($attribute->getFrontendLabel().' Alias ('.$attribute->getAttributeCode().')'),
                        'title' => __($attribute->getFrontendLabel().' Alias'),
                        'required' => false,
                        'value' => $model_attributes[$attribute->getAttributeCode()]
                    ]
                );
                unset($model_attributes[$attribute->getAttributeCode()]);
            } else {
                $fieldset->addField(
                    'attribute_alias_'.$attribute->getAttributeCode(),
                    'text',
                    [
                        'name' => 'attribute_alias['.$attribute->getAttributeCode().']',
                        'label' => __($attribute->getFrontendLabel().' Alias ('.$attribute->getAttributeCode().')'),
                        'title' => __($attribute->getFrontendLabel().' Alias'),
                        'required' => false
                    ]
                );
            }
        }
        
        $fieldset->addField(
            'addCustomField',
            'button',
            [
                'name' => 'addCustomField',
                'label' => '',
                'value' => __('Add Custom Field'),
                'title' => __('Add Custom Field')
            ]
        );
        
        $custom_pre_values = [];
        foreach($model_custom_attributes as $title => $value) {
            $custom_pre_values[] = $title."|%|".$value;
        }
        $fieldset->addField(
            'custom_pre',
            'hidden',
            [
                'name' => 'custom_pre',
                'value' => implode("|$|", $custom_pre_values)
            ]
        );

        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}