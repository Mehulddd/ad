<?php

namespace Pinamondo\Exporter\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;

class Edit extends \Magento\Backend\App\Action
{
    /**
     * Core registry
     *
     * @var \Magento\Framework\Registry
     */
    protected $_coreRegistry = null;

    /**
     * @var \Magento\Framework\View\Result\PageFactory
     */
    protected $resultPageFactory;

    /**
     * @param Action\Context $context
     * @param \Magento\Framework\View\Result\PageFactory $resultPageFactory
     * @param \Magento\Framework\Registry $registry
     */
    public function __construct(
        Action\Context $context,
        \Magento\Framework\View\Result\PageFactory $resultPageFactory,
        \Magento\Framework\Registry $registry
    ) {
        $this->resultPageFactory = $resultPageFactory;
        $this->_coreRegistry = $registry;
        parent::__construct($context);
    }

    /**
     * Init actions
     *
     * @return \Magento\Backend\Model\View\Result\Page
     */
    protected function _initAction()
    {
        // load layout, set active menu and breadcrumbs
        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->resultPageFactory->create();
        $resultPage->setActiveMenu('Pinamondo_Exporter::index')
            ->addBreadcrumb(__('Exporter'), __('Exporter'))
            ->addBreadcrumb(__('Manage Exporters'), __('Manage Exporters'));
        return $resultPage;
    }

    /**
     * Edit Seotext post
     *
     * @return \Magento\Backend\Model\View\Result\Page|\Magento\Backend\Model\View\Result\Redirect
     * @SuppressWarnings(PHPMD.NPathComplexity)
     */
    public function execute()
    {
        $id = $this->getRequest()->getParam('id');
        $model = $this->_objectManager->create('Pinamondo\Exporter\Model\Exporter');

        if ($id) {
            $model->load($id);
            if (!$model->getId()) {
                $this->messageManager->addError(__('This Exporter no longer exists.'));
                /** \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
                $resultRedirect = $this->resultRedirectFactory->create();

                return $resultRedirect->setPath('*/*/');
            }
        }
        
        $data = $this->_objectManager->get('Magento\Backend\Model\Session')->getFormData(true);
        if (!empty($data)) {
            $model->setData($data);
        }

        $this->_coreRegistry->register('exporter_data', $model);
        
        $coll = $this->_objectManager->create(\Magento\Eav\Model\ResourceModel\Entity\Attribute\Collection::class);
        $coll->addFieldToFilter(\Magento\Eav\Model\Entity\Attribute\Set::KEY_ENTITY_TYPE_ID, 4);
        $attrAll = $coll->load()->getItems();
        $attributes = [];
        foreach ($attrAll as $attribute) {
            $attributes[] = $attribute->getAttributeCode();
        }
        $this->_coreRegistry->register('exporter_attributes', $attrAll);
        
        $attributeDBModels = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterAlias')->getCollection()
                                ->addFieldToFilter('pinamondo_exporter_id', $id)->getData();

        $attributeDBList = [];
        foreach($attributeDBModels as $attributeDBModel) {
            $attributeDBList[$attributeDBModel['product_attribute']] = $attributeDBModel['attribute_alias'];
        }
        $this->_coreRegistry->register('exporter_db_attributes', $attributeDBList);
        
        $customAttributeDBModels = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias')->getCollection()
                                ->addFieldToFilter('pinamondo_exporter_id', $id)->getData();
        $customAttributeDBList = [];
        foreach($customAttributeDBModels as $customAttributeDBModel) {
            $customAttributeDBList[$customAttributeDBModel['custom_title']] = $customAttributeDBModel['custom_value'];
        }
        $this->_coreRegistry->register('exporter_db_custom_attributes', $customAttributeDBList);
        
//        $this->_coreRegistry->register('exporter_data', $model);

        /** @var \Magento\Backend\Model\View\Result\Page $resultPage */
        $resultPage = $this->_initAction();
        $resultPage->addBreadcrumb(
            $id ? __('Edit Exporter') : __('New Exporter'),
            $id ? __('Edit Exporter') : __('New Exporter')
        );
        $resultPage->getConfig()->getTitle()->prepend(__('Exporters'));
        $resultPage->getConfig()->getTitle()
            ->prepend($model->getId() ? $model->getTitle() : __('New Exporter'));

        return $resultPage;
    }
}