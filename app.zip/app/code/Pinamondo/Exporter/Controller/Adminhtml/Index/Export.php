<?php

namespace Pinamondo\Exporter\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;
use PHPExcel;
use PHPExcel_IOFactory;

class Export extends \Magento\Backend\App\Action
{
    
    /**
     * Delete action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $fileType = $this->getRequest()->getParam('fileType');
        $id = $this->getRequest()->getParam('id');
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($id) {
            try {
                $content = [];
                $heading = [];
                
                $exportModel = $this->_objectManager->create('Pinamondo\Exporter\Model\Exporter');
                $exportModel->load($id);
                $exportColumns = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterAlias')->getCollection()
                                ->addFieldToFilter('pinamondo_exporter_id', $id)->getData();
                $attributeList = [];
                foreach($exportColumns as $attributeDBModel) {
                    $attributeList[] = $attributeDBModel['product_attribute'];
                    $heading[] = $attributeDBModel['attribute_alias'];
                    $attributeMap[$attributeDBModel['product_attribute']] = $attributeDBModel['attribute_alias'];
                }
                $exportColumns = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias')->getCollection()
                                ->addFieldToFilter('pinamondo_exporter_id', $id)->getData();
                foreach($exportColumns as $attributeDBModel) {
                    $attributeList[] = $attributeDBModel['custom_title'];
                    $heading[] = $attributeDBModel['custom_title'];
                    $attributeMap[$attributeDBModel['custom_title']] = $attributeDBModel['custom_value'];
                }
                
                $content[] = $heading;
                
                $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');
                $productCollection->addFieldToFilter("type_id", "configurable");
                $productCollection->addAttributeToSelect("*");
                $productCollection->load();
                $categoryFactory = $this->_objectManager->create('Magento\Catalog\Model\CategoryFactory');
                
                $productPreList = [];
                $productChildList = [];
                
                foreach($productCollection as $product) {
                    if ($product->getVisibility() == 1 || $product->getStatus() == "2")
                        continue;
                    $genders = [];
                    if (in_array("category_ids", $attributeList)) {
                        $categories = [];
                        foreach($product->getCategoryIds() as $categoryId) {
                            $category = $categoryFactory->create();
                            $category->load($categoryId);
                            if ($category->getName() == "Men" || $category->getName() == "Women") {
                                $genders[] = $category->getName();
                            }
                            if (
                                    $category->getName() != "Men" &&
                                    $category->getName() != "Women" && 
                                    !in_array($category->getName(), $categories)
                                    )
                                $categories[] = $category->getName();
                        }
                        $gender = "";
                        if (count($genders) == 2) {
                            $gender = "unisex";
                        } else if (count($genders)) {
                            $gender = $genders[0];
                        }
                        $productMap[$attributeMap["category_ids"]] = $gender." ".implode(",", $categories);
                        $processedAttributes[] = "category_ids";
                    }

                    $attributes = $product->getAttributes();
                    foreach ($attributes as $attribute) {
                        if (!in_array($attribute->getAttributeCode(), $attributeList) || $attribute->getAttributeCode() == "category_ids") {
                            continue;
                        }
                        $processedAttributes[] = $attribute->getAttributeCode();
                        $productMap[$attributeMap[$attribute->getAttributeCode()]] = $attribute->getFrontend()->getValue($product) ?
                                $attribute->getFrontend()->getValue($product) : "";
                        if ($attribute->getAttributeCode() == "description") {
                            $productMap[$attributeMap[$attribute->getAttributeCode()]] = strip_tags($productMap[$attributeMap[$attribute->getAttributeCode()]]);
                            $productMap[$attributeMap[$attribute->getAttributeCode()]] = str_replace("&nbsp;", "", $productMap[$attributeMap[$attribute->getAttributeCode()]]);
                        }
                    }
                    $price;
                    $sizeGroup = [];
                    
                    $associatedProductIds = $product->getTypeInstance()->getUsedProductIds($product);
                    $_subproducts = $this->_objectManager->create('Magento\Catalog\Model\Product')->getCollection()
                                ->addIdFilter($associatedProductIds);

                    $populateData = true;
                    foreach ($associatedProductIds as $associatedProductId) {
                        $productChildList[] = $associatedProductId;
                        $associatedProduct = $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ProductRepository')
                                                ->getById($associatedProductId);
                        $sizeGroup[] = (int)$associatedProduct->getAttributeText('size');
                        
                        if ($populateData) {
                            $attributes = $associatedProduct->getAttributes();
                            foreach ($attributes as $attribute) {
                                if ($attribute->getAttributeCode() !== "price" || !isset($attributeMap[$attribute->getAttributeCode()])) {
                                    continue;
                                }
                                $processedAttributes[] = $attribute->getAttributeCode();
                                $productMap[$attributeMap[$attribute->getAttributeCode()]] = $attribute->getFrontend()->getValue($associatedProduct) ?
                                        $attribute->getFrontend()->getValue($associatedProduct) : "";
                                
                                if ($attribute->getAttributeCode() == "description") {
                                    $productMap[$attributeMap[$attribute->getAttributeCode()]] = strip_tags($productMap[$attributeMap[$attribute->getAttributeCode()]]);
                                    $productMap[$attributeMap[$attribute->getAttributeCode()]] = str_replace("&nbsp;", "", $productMap[$attributeMap[$attribute->getAttributeCode()]]);
                                }
                            }
                            $populateData = false;
                        }
                    }
                    if (isset($attributeMap['size'])) {
                        sort($sizeGroup);
                        $productMap[$attributeMap['size']] = $sizeGroup[0].'-'.$sizeGroup[count($sizeGroup)-1];
                    }
                    
                    foreach($attributeList as $attr) {
                        if (!in_array($attr, $processedAttributes)) {
                            $productMap[$attr] = $attributeMap[$attr];
                        }
                    }
                    $content[] = array_merge(array_flip($heading), $productMap);
                }
                
                $productCollection = $this->_objectManager->create('Magento\Catalog\Model\ResourceModel\Product\Collection');
                $productCollection->addFieldToFilter("type_id", "virtual");
                $productCollection->addAttributeToSelect("*");
                $productCollection->load();
                $categoryFactory = $this->_objectManager->create('Magento\Catalog\Model\CategoryFactory');
                
                $productPreList = [];
                foreach($productCollection as $product) {
                    if (in_array($product->getId(), $productChildList) || $product->getVisibility() == 1 || $product->getStatus() == "2")
                        continue;
                    
                    $productMap = [];
                    $productRow = [];
                    $processedAttributes = [];
                    $genders = [];
                    
                    $product1 = $this->_objectManager->create('Magento\ConfigurableProduct\Model\ResourceModel\Product\Type\Configurable')->getParentIdsByChild($product->getId());
                    if (empty($product1)) {
                        $productPreList[$product->getId()] = [];
                    }
                    if (in_array("category_ids", $attributeList)) {
                        $categories = [];
                        foreach($product->getCategoryIds() as $categoryId) {
                            if ($category->getName() == "Men" || $category->getName() == "Women") {
                                $genders[] = $category->getName();
                            }
                            $category = $categoryFactory->create();
                            $category->load($categoryId);	
                            if (
                                    $category->getName() != "Men" &&
                                    $category->getName() != "Women" && 
                                    !in_array($category->getName(), $categories)
                                    )
                                $categories[] = $category->getName();
                        }
                        $gender = "";
                        if (count($genders) == 2) {
                            $gender = "unisex";
                        } else if (count($genders)) {
                            $gender = $genders[0];
                        }
                        $productMap[$attributeMap["category_ids"]] = $gender." ".implode(",", $categories);
                        $processedAttributes[] = "category_ids";
                    }

                    $attributes = $product->getAttributes();
                    foreach ($attributes as $attribute) {
                        if (!in_array($attribute->getAttributeCode(), $attributeList) || $attribute->getAttributeCode() == "category_ids") {
                            continue;
                        }
                        $processedAttributes[] = $attribute->getAttributeCode();
                        $productMap[$attributeMap[$attribute->getAttributeCode()]] = $attribute->getFrontend()->getValue($product) ?
                                $attribute->getFrontend()->getValue($product) : "";

                        if ($attribute->getAttributeCode() == "description") {
                            $productMap[$attributeMap[$attribute->getAttributeCode()]] = strip_tags($productMap[$attributeMap[$attribute->getAttributeCode()]]);
                            $productMap[$attributeMap[$attribute->getAttributeCode()]] = str_replace("&nbsp;", "", $productMap[$attributeMap[$attribute->getAttributeCode()]]);
                        }
                    }
                    foreach($attributeList as $attr) {
                        if (!in_array($attr, $processedAttributes)) {
                            $productMap[$attr] = $attributeMap[$attr];
                        }
                    }
                    $content[] = array_merge(array_flip($heading), $productMap);
                }
                
                $outputFile = "/tmp/products_". date('Ymd_His').".".$fileType;
                $handle = fopen($outputFile, 'w');
                if ($fileType == "csv") {
                    foreach ($content as $line) {
                        fputcsv($handle, $line);
                    }
                } else if ($fileType == "xls" || $fileType == "xlsx") {
                    $PHPExcel = new PHPExcel();
                    $PHPExcel->getActiveSheet()->fromArray($content, null, 'A1' );
                    $PHPExcel->getActiveSheet()->setTitle("Sheet 1");
                    $PHPExcel->setActiveSheetIndex(0);
                    $objWriter = PHPExcel_IOFactory::createWriter($PHPExcel, 'Excel2007');
                    $objWriter->save($outputFile);
                } else {

                }
                
                $this->downloadCsv($outputFile, $fileType);
                unlink($outputFile);
            } catch (\Exception $e) {
                $this->messageManager->addError($e->getMessage());
                return $resultRedirect->setPath('*/*/');
            }
        }
    }
    
    public function downloadCsv($file, $fileType){
        if (file_exists($file)) {
            if ($fileType == "xls")
                $contentType = "application/vnd.ms-excel";
            else if ($fileType == "xlsx")
                $contentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
            else
                $contentType = "application/csv";
            //set appropriate headers
            header('Content-Description: File Transfer');
            header('Content-Type: '.$contentType);
            header('Content-Disposition: attachment; filename='.basename($file));
            header('Expires: 0');
            header('Cache-Control: must-revalidate');
            header('Pragma: public');
            header('Content-Length: ' . filesize($file));
            ob_clean();flush();
            readfile($file);
        } 
    }
}