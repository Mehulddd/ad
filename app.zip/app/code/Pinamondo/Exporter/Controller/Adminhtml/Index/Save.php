<?php

namespace Pinamondo\Exporter\Controller\Adminhtml\Index;

use Magento\Backend\App\Action;
use Magento\TestFramework\ErrorLog\Logger;

class Save extends \Magento\Backend\App\Action
{

    /**
     * @param Action\Context $context
     */
    public function __construct(Action\Context $context)
    {
        parent::__construct($context);
    }

    /**
     * {@inheritdoc}
     */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Pinamondo_Exporter::save');
    }

    /**
     * Save action
     *
     * @return \Magento\Framework\Controller\ResultInterface
     */
    public function execute()
    {
        $data = $this->getRequest()->getPostValue();
        /** @var \Magento\Backend\Model\View\Result\Redirect $resultRedirect */
        $resultRedirect = $this->resultRedirectFactory->create();
        if ($data) {
            /** @var \Pinamondo\Seotext\Model\Post $model */
            $model = $this->_objectManager->create('Pinamondo\Exporter\Model\Exporter');

            $id = $this->getRequest()->getParam('id');
            if ($id) {
                $model->load($id);
            }
//            var_dump($data["exporter_name"]); exit;
            if (!$id) {
                $model->setData(["exporter_name" => $data["exporter_name"]]);
                $model->save();
                $id = $model->getId();
            }
            
            $attributeDBModels = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterAlias')->getCollection()
                                ->addFieldToFilter('pinamondo_exporter_id', $id)->getData();

            $attributeDBList = [];
            foreach($attributeDBModels as $attributeDBModel) {
                $attributeDBList[$attributeDBModel['product_attribute']] = $attributeDBModel['id'];
            }
            $processedAttributes = [];
            foreach($data['attribute_alias'] as $attribute => $aliasName) {
                if (!empty(trim($aliasName)) || isset($attributeDBList[$attribute])) {
                    $attributeModel = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterAlias');
                    if ($attributeDBModels && isset($attributeDBList[$attribute])) {
                        $attributeModel->load($attributeDBList[$attribute]);
                        if (empty(trim($aliasName)))
                            $attributeModel->delete();
                        else
                            $attributeModel->setData(["id" => $attributeDBList[$attribute], "pinamondo_exporter_id" => $id, "product_attribute" => $attribute, "attribute_alias" => $aliasName ]);
                    } else {
                        $attributeModel->setData(["pinamondo_exporter_id" => $id, "product_attribute" => $attribute, "attribute_alias" => $aliasName ]);
                    }
                    $attributeModel->save();
                }
//                $processedAttributes[] = $attribute;
            }
            
            if (isset($data['custom_element'])) {
                foreach($data['custom_element'] as $customElement) {
                    $customTitle = $customElement["head_title"];
                    $customValue = $customElement["value"];
                    if (!empty($customTitle)) {
                        $customAttributeDBModel = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias')->getCollection()
                                    ->addFieldToFilter('pinamondo_exporter_id', $id)
                                    ->addFieldToFilter('custom_title', $customTitle)
                                    ->getFirstItem()->getData();
                        $attributeModel = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias');
                        if ($customAttributeDBModel) {
//                            var_dump($customAttributeDBModel);
                            $attributeModel->load($customAttributeDBModel["id"]);
                            $attributeModel->setData(["id" => $customAttributeDBModel["id"], "pinamondo_exporter_id" => $id, "custom_title" => $customTitle, "custom_value" => $customValue ]);
                        } else {
                            $attributeModel->setData(["pinamondo_exporter_id" => $id, "custom_title" => $customTitle, "custom_value" => $customValue ]);
                        }
                        $attributeModel->save();
                        $processedAttributes[] = $customTitle;
                    }
                }
            }
            $customAttributeDBModels = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias')->getCollection()->getData();
            foreach($customAttributeDBModels as $customAttrDBModelData) {
                if (!in_array($customAttrDBModelData["custom_title"], $processedAttributes)) {
                    $attrDBModel = $this->_objectManager->create('Pinamondo\Exporter\Model\ExporterCustomAlias');
                    $attrDBModel->load($customAttrDBModelData["id"]);
                    $attrDBModel->delete();
                    $attrDBModel->save();
                }
            }
//var_dump($data['attribute_alias']);
//exit;
//            $model->setData($data);
//
//            $this->_eventManager->dispatch(
//                'exporter_data_prepare_save',
//                ['post' => $model, 'request' => $this->getRequest()]
//            );

            try {
//                $model->save();
                $this->messageManager->addSuccess(__('You saved this Exporter.'));
                $this->_objectManager->get('Magento\Backend\Model\Session')->setFormData(false);
                if ($this->getRequest()->getParam('back')) {
                    return $resultRedirect->setPath('*/*/edit', ['id' => $model->getId(), '_current' => true]);
                }
                return $resultRedirect->setPath('*/*/');
            } catch (\Magento\Framework\Exception\LocalizedException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\RuntimeException $e) {
                $this->messageManager->addError($e->getMessage());
            } catch (\Exception $e) {
                $this->messageManager->addException($e, __('Something went wrong while saving the Exporter.'));
            }

            $this->_getSession()->setFormData($data);
            return $resultRedirect->setPath('*/*/edit', ['id' => $this->getRequest()->getParam('id')]);
        }
        return $resultRedirect->setPath('*/*/');
    }
}