<?php

namespace Pinamondo\Exporter\Model\Config\Source;

class ExporterId implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        $om = \Magento\Framework\App\ObjectManager::getInstance();

        $connection = $om->create('\Magento\Framework\App\ResourceConnection')
            ->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tblExporter = $connection->getTableName('pinamondo_exporter');
        $results = $connection->fetchAll('SELECT id, exporter_name FROM `'.$tblExporter.'`');

        foreach($results as $result) {
            $fl['label'] = __($result['name']);
            $fl['value'] = $result['id'];
            $list[] = $fl;
        }

        return $list;
    }
}