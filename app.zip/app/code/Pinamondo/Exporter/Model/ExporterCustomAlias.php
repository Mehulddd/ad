<?php

namespace Pinamondo\Exporter\Model;

class ExporterCustomAlias extends \Magento\Framework\Model\AbstractModel
{

    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Pinamondo\Exporter\Model\ResourceModel\ExporterCustomAlias');
    }
}