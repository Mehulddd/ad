<?php

//namespace Pinamondo\Exporter\Model\ResourceModel\Exporter;
//namespace Pinamondo\Exporter\Model\ResourceModel\Affiliate;
namespace Pinamondo\Exporter\Model\ResourceModel;

class ExporterAlias extends \Magento\Framework\Model\ResourceModel\Db\AbstractDb
{
    /**
     * Initialize resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('pinamondo_exporter_aliases', 'id');
    }
}