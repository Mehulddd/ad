<?php

namespace Pinamondo\Exporter\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('pinamondo_exporter'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                11,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'exporter_name',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Exporter Name'
            )
            ->setComment('Pinamondo Exporters Table');
        $installer->getConnection()->createTable($table);
        
        $table = $installer->getConnection()
            ->newTable($installer->getTable('pinamondo_exporter_aliases'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                11,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'pinamondo_exporter_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                11,
                ['nullable'  => false, 'unsigned' => true],
                'Pinamondo Exporter Instance'
            )
            ->addForeignKey(
                $installer->getFkName(
                    'pinamondo_exporter_aliases',
                    'pinamondo_exporter_id',
                    'pinamondo_exporter',
                    'id'
                ),
                'pinamondo_exporter_id', 
                $installer->getTable('pinamondo_exporter'), 
                'id',
                \Magento\Framework\Db\Ddl\Table::ACTION_CASCADE
            )
            ->addColumn(
                'product_attribute',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Product Attribute'
            )
            ->addColumn(
                'attribute_alias',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Attribute Alias'
            )
            ->setComment('Pinamondo Exporter Aliases Table');
        $installer->getConnection()->createTable($table);
        
        $table = $installer->getConnection()
            ->newTable($installer->getTable('pinamondo_exporter_custom_aliases'))
            ->addColumn(
                'id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                11,
                ['identity' => true, 'unsigned' => true, 'nullable' => false, 'primary' => true],
                'Id'
            )
            ->addColumn(
                'pinamondo_exporter_id',
                \Magento\Framework\DB\Ddl\Table::TYPE_INTEGER,
                11,
                ['nullable'  => false, 'unsigned' => true],
                'Pinamondo Exporter Instance'
            )
            ->addForeignKey(
                $installer->getFkName(
                    'pinamondo_exporter_custom_aliases',
                    'pinamondo_exporter_id',
                    'pinamondo_exporter',
                    'id'
                ),
                'pinamondo_exporter_id', 
                $installer->getTable('pinamondo_exporter'), 
                'id',
                \Magento\Framework\Db\Ddl\Table::ACTION_CASCADE
            )
            ->addColumn(
                'custom_title',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Product Custom Title'
            )
            ->addColumn(
                'custom_value',
                \Magento\Framework\DB\Ddl\Table::TYPE_TEXT,
                255,
                ['nullable' => false],
                'Product Custom Value'
            )
            ->setComment('Pinamondo Exporters Custom Alias Table');
        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}