<?php

namespace Pinamondo\Listingteaser\Model\Config\Source;

class Teasertype implements \Magento\Framework\Option\ArrayInterface
{
    /**
     * {@inheritdoc}
     *
     * @codeCoverageIgnore
     */
    public function toOptionArray()
    {
        return [
            ['value' => 'ad', 'label' => __('Adbox (default)')],
            ['value' => 'newsletter', 'label' => __('Newsletter')]
        ];
    }
}