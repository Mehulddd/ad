<?php

namespace Pinamondo\Newsletter\Controller\Index;

use \Magento\Framework\App\Action\Action;

class Index extends Action
{
    /**
     * @var  \Magento\Framework\View\Result\Page
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                    \Magento\Framework\View\Result\PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {

        if (!empty($_POST)) {

        //subscriber details
        if (isset($_POST['newsletter']['email'])) {
                $request['email'] = $_POST['newsletter']['email'];
                $request['name'] = isset($_POST['newsletter']['name']) ? $_POST['newsletter']['name'] : '';
                $request['instagram'] = isset($_POST['newsletter']['instagram']) ? $_POST['newsletter']['instagram'] : '';
                $request['gender'] = isset($_POST['newsletter']['gender']) ? $_POST['newsletter']['gender'] : '';
        }
        else if (isset($_POST['email']) && isset($_POST['gender'])) {
                $request['email'] = $_POST['email'];
                $request['name'] = '';
                $request['instagram'] = '';
                $request['gender'] = isset($_POST['gender']) ? $_POST['gender'] : '';
        }
        else {
                return $this->resultRedirectFactory->create()->setUrl('/');
        }

        //db lookup
        $subscribe = $this->_objectManager->create('Pinamondo\Newsletter\Model\Newsletter');

        $count = $subscribe->getCollection()
            ->addFieldToFilter('email', $request['email'])->count();

        if ($count>0) {
            return $this->resultRedirectFactory->create()->setUrl('/newsletter/index/failure?email='.$request['email']);
        }
        else {
            $subscribe->setFirstname($request['name']);
            $subscribe->setLastname($request['instagram']);
            $subscribe->setEmail($request['email']);
            $subscribe->setConfirmationSent(date("Y-m-d H:i:s"));

            if ($request['gender']=='man') {
                $mcListId = '56e838b07b';
                $subscribe->setMale(true);
            }
            else if ($request['gender']=='woman') {
                $mcListId = '51f9941249';
                $subscribe->setFemale(true);
            }

            if ($subscribe->save()) {
                //mailchimp credentials
                $mcApiKey = 'ee10a682ffb92a6b87e34bffda3ae7c3-us13';
                $mcDoubleOptIn = false;
                $mcSendWelcome = false;
                $updateExisting = false;
                $replaceInterests = true;

                try {
                    $mc = new \Mailchimp($mcApiKey);

                    $result = $mc->lists->subscribe($mcListId,
                        array('email'=> $request['email']),
                        array(
                            'NAME' => $request['name'],
                            'INSTAGRAM' => $request['instagram'],
                            'GENDER' => $request['gender']
                        ),
                        'html',
                        $mcDoubleOptIn,
                        $updateExisting,
                        $replaceInterests,
                        $mcSendWelcome
                    );

                return $this->resultRedirectFactory->create()->setUrl('/newsletter/index/success?email='.$request['email'].'&gender='.$request['gender']);
                } catch (\Mailchimp_Error $e) {
                    error_log($e->getCode().' '.$e->getMessage());
                }
            }
        }
    }

    $resultPageFactory = $this->resultPageFactory->create();

    // Add page title
    //$resultPageFactory->getConfig()->getTitle()->set(__('Example module'));

    // Add breadcrumb
    /** @var \Magento\Theme\Block\Html\Breadcrumbs */
    $breadcrumbs = $resultPageFactory->getLayout()->getBlock('breadcrumbs');

    return $resultPageFactory;
    }
}
