<?php

namespace Pinamondo\Newsletter\Controller\Index;

use \Magento\Framework\App\Action\Action;

class Success extends Action
{
    /**
     * @var  \Magento\Framework\View\Result\Page
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                \Magento\Framework\View\Result\PageFactory $resultPageFactory)
    {
        parent::__construct($context);
        $this->resultPageFactory = $resultPageFactory;
    }

    public function execute()
    {
        if (isset($_GET) && isset($_GET['email'])) {

            //subscriber details
            $request['email'] = $_GET['email'];

            //db lookup
            $subscribe = $this->_objectManager->create('Pinamondo\Newsletter\Model\Newsletter');

            $count = $subscribe->getCollection()
                ->addFieldToFilter('email', $request['email'])->count();

            if ($count==0) {
                return $this->resultRedirectFactory->create()->setUrl('/');
            }
        }

        $resultPageFactory = $this->resultPageFactory->create();

        // Add page title
        //$resultPageFactory->getConfig()->getTitle()->set(__('Example module'));

        // Add breadcrumb
        /** @var \Magento\Theme\Block\Html\Breadcrumbs */
        $breadcrumbs = $resultPageFactory->getLayout()->getBlock('breadcrumbs');

        return $resultPageFactory;
    }
}
