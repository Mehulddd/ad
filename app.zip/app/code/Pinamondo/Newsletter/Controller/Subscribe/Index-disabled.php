<?php

namespace Pinamondo\Newsletter\Controller\Subscribe;

use \Magento\Framework\App\Action\Action;

class Index extends Action
{
    /**
     * @var  \Magento\Framework\View\Result\Page
     */
    protected $resultPageFactory;

    /**
     * @param \Magento\Framework\App\Action\Context $context
     */
    public function __construct(\Magento\Framework\App\Action\Context $context,
                                \Magento\Framework\Controller\Result\JsonFactory $resultJsonFactory)
    {
        parent::__construct($context);
        $this->resultJsonFactory = $resultJsonFactory;
    }

    /**
     * Blog Index, shows a list of recent blog posts.
     *
     * @return \Magento\Framework\View\Result\JsonFactory
     */
    public function execute()
    {
        $success = true;
        $errorMessage = '';

        /*
         * Comment: It was disable due to issues mobile version had with ajax call
         * when widget tried to subscribe was fully redirecting to this page
         *
        $topic = $this->getRequest()->getParam('topic');
        $topic = isset($topic) ? $topic : 'trend';

        $gender = $this->getRequest()->getParam('gender');
        if (!isset($gender)) {
            $success = false;
            $errorMessage = 'Gender is mandatory';
        }

        $email = $this->getRequest()->getParam('email');
        if (!isset($email)) {
            $success = false;
            $errorMessage = 'Email is mandatory';
        }

        if ($success===true) {

        //db lookup
        $subscribe = $this->_objectManager->create('Pinamondo\Newsletter\Model\Newsletter');

        $count = $subscribe->getCollection()
                ->addFieldToFilter('email', $email)->count();

        if ($count>0) {
            $success = false;
            $errorMessage = 'Email is already subscribed';
        }
        else {
            $subscribe->setEmail($email);
            $subscribe->setTopic($topic);
            $subscribe->setConfirmationSent(date("Y-m-d H:i:s"));

            if ($gender=='male') {
            $mcListId = '56e838b07b';
            $subscribe->setMale(true);
            }
            else if ($gender=='female') {
            $mcListId = '51f9941249';
            $subscribe->setFemale(true);
            }

            if ($subscribe->save()) {

                //subscriber details
                $request['email'] = $email;
                $request['name'] = '';
                $request['instagram'] = '';

                //mailchimp credentials
                $mcApiKey = 'ee10a682ffb92a6b87e34bffda3ae7c3-us13';
                $mcDoubleOptIn = false;
                $mcSendWelcome = false;
                $updateExisting = false;
                $replaceInterests = true;

                try {
                    $mc = new \Mailchimp($mcApiKey);

                    $result = $mc->lists->subscribe($mcListId,
                        array('email'=> $request['email']),
                        array(
                            'GENDER' => $gender
                        ),
                        'html',
                        $mcDoubleOptIn,
                        $updateExisting,
                        $replaceInterests,
                        $mcSendWelcome
                    );

                } catch (\Mailchimp_Error $e) {
                    error_log($e->getCode().' '.$e->getMessage());
                }

            }
        }

        }
        */

        /** @var \Magento\Framework\Controller\Result\Json $result */
        $result = $this->resultJsonFactory->create();
        return $result->setData(['success' => $success, 'errorMessage' => $errorMessage]);
    }
}