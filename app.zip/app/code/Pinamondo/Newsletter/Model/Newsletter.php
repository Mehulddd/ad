<?php

namespace Pinamondo\Newsletter\Model;

use Magento\Framework\Model\AbstractModel;

class Newsletter extends AbstractModel
{
    /**
     * Define resource model
     */
    protected function _construct()
    {
        $this->_init('Pinamondo\Newsletter\Model\Resource\Newsletter');
    }
}