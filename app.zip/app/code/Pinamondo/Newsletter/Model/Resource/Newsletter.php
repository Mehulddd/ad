<?php

namespace Pinamondo\Newsletter\Model\Resource;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;

class Newsletter extends AbstractDb
{
    /**
     * Define main table
     */
    protected function _construct()
    {
        $this->_init('pinamondo_newsletter', 'id');
    }
}