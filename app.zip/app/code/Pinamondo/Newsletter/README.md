------------

Installation
------------

Run the following to check if module is listed

    ./bin/magento module:status

List of disabled modules:
Pinamondo_Newsletter

Run to enable module

    ./bin/magento module:enable Pinamondo_Newsletter

The following modules have been enabled:
- Pinamondo_Newsletter


Run upgrade to install db schema

    ./bin/magento setup:upgrade
