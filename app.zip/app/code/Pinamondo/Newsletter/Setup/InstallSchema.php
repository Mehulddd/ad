<?php

namespace Pinamondo\Newsletter\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     * Structure taken from Kleidoo Newsletter Subscriptions table
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('pinamondo_newsletter'))
            ->addColumn('id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true])
            ->addColumn('email', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('male', Table::TYPE_SMALLINT, null, ['nullable' => true, 'default' => '0'])
            ->addColumn('female', Table::TYPE_SMALLINT, null, ['nullable' => true, 'default' => '0'])
            ->addColumn('title', Table::TYPE_TEXT, 255, ['nullable' => false], 'Blog Title')
            ->addColumn('firstname', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('lastname', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('topic', Table::TYPE_TEXT, 50, ['nullable' => true, 'default' => null])
            ->addColumn('dob', Table::TYPE_DATETIME, null, ['nullable' => true, 'default' => null])
            ->addColumn('voucher_id', Table::TYPE_INTEGER, null, ['nullable' => false])
            ->addColumn('tmp_confirmcode', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('active', Table::TYPE_SMALLINT, null, ['nullable' => false, 'default' => '0'])
            ->addColumn('confirmation_sent', Table::TYPE_DATETIME, null, ['nullable' => false])
            ->addIndex($installer->getIdxName('pm_nwlt_email_idx', ['email']), ['email'])
            ->setComment('Pinamondo Newsletter Subscribers');

        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}