<?php

namespace Pinamondo\Newsletter\Setup;

use Magento\Framework\Setup\UpgradeSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class UpgradeSchema implements UpgradeSchemaInterface
{
    /**
     * Updates DB schema for a module
     * Adding Link to Magento Customer
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function upgrade(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $installer->getConnection()->addColumn(
            $installer->getTable('pinamondo_newsletter'),
            'customer_id',
            array(
                'type' => Table::TYPE_INTEGER,
                'nullable' => true,
                'default' => '0',
                'comment' => 'Customer'
            )
        );

        $installer->endSetup();
    }
}