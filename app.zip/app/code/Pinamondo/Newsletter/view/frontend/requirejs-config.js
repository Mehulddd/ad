/**
 * Pinamondo
 */

var config = {
    "map": {
        "*": {
            "subscribe": "Pinamondo_Newsletter/js/subscribe"
        }
    }
};
