/**
 * Pinamondo
 */
/*jshint browser:true jquery:true*/
/*global confirm:true*/
define([
    "jquery",
    "Magento_Ui/js/modal/alert",
    'mage/translate' // for i18n
], function($, alert){
    "use strict";

    /**
     * Init subscribe block. Could be evaluated on different subscribe blocks.
     * @param container Element or jQuery
     * @param okButtonCallback function callback
     * @param closeButtonCallback function callback
     */
    function initSubscribe(container, okButtonCallback, closeButtonCallback) {
        var rememberedEmail = ''; // remember email to replace it temporary for warning
        var warningActive = false; // flag for detecting input value (is there warning message or actual data)

        var $container = $(container);
        var path = $container.find('.subscribe__form').attr('action'); // /newsletter_ajax/subscribe/index
        var $subscribeMessage = $container.find('[data-role="subscribe-message"]');
        var $subscribeButtons = $container.find('[name="gender"]');
        var $subscribeEmail = $container.find('[name="email"]');
        var $subscribeTopic = $container.find('[name="topic"]');

        $subscribeEmail.val(''); // clear value in case there is something in browser cache for forms

        var validateEmail = function(email) {
            var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
            return re.test(email);
        };
        var showModalWindow = function() {
            $subscribeMessage.fadeIn(250);
            $subscribeMessage.find('[data-role="button-ok"]').focus();
        };
        var hideModalWindow = function() {
            $subscribeMessage.fadeOut(250);
            // clear value
            $subscribeEmail.val('');
            // clear memorized email
            rememberedEmail = '';
        };
        var showWarningMessage = function () {
            rememberedEmail = $subscribeEmail.val();
            $subscribeEmail.val($.mage.__('Email is not valid!'));
            $subscribeEmail.addClass('subscribe__email_warning');
            warningActive = true;
        };
        var clearWarningMessage = function(){
            $subscribeEmail.val(rememberedEmail);
            rememberedEmail = '';
            $subscribeEmail.removeClass('subscribe__email_warning');
            warningActive = false;
        };
        /* Actual subscribing is going on here */
        var subscribe = function(e){
            var email = $subscribeEmail.val();

            if (!validateEmail(email)) {
                showWarningMessage();
                return false;
            }

            var gender = $(e.target).val();
            var topic = $subscribeTopic.val();

            //console.log('Email: ' + email + ', gender: ' + gender + ', topic:' + topic);

            // Send request to server. If success, show modal. Else, show Sorry.
            $.getJSON(path, {email: email, gender: gender, topic: topic})
                .done(function(data){
                    if (data.success !== true) {
                        // TODO check error status, show message if error in data
                        //console.log(JSON.stringify(data));
                        alert({
                            title: $.mage.__('Warning'),
                            content: data.errorMessage
                        });
                    }
                    else {
                        // show modal window if success
                        showModalWindow();
                    }
                })
                // TODO do something if network error (404 et c.)
                .fail(function( jqxhr, textStatus, error ) {
                    var err = textStatus + ', ' + error;
                    console.log( 'Request Failed: ' + err );
                });

            return false; // prevent defaults for button clicks
        };

        /* bind events for UI */
        $subscribeMessage.find('[data-role="button-ok"]').click(function(){
            hideModalWindow();
            okButtonCallback($container);
        });
        $subscribeMessage.find('[data-role="button-close"]').click(function(){
            hideModalWindow();
            closeButtonCallback($container);
        });
        $subscribeButtons.click(subscribe);
        $subscribeEmail.on('click keydown focus', function(){
            if (warningActive) {
                clearWarningMessage();
            }
        });
    }

    // create jQuery plugin
    $.fn.subscribeWidget = function(options){

        // Options
        var settings = $.extend({
            // These are the defaults.
            okButtonCallback: function(/* $container */){}, // callback to run after pressing the 'ok' button in the message window. The container of the widget is passed as a parameter.
            closeButtonCallback: null // callback to run after pressing the 'close' button in the message window
        }, options );

        // init
        this.each(function(index, item){
            initSubscribe(
              item,
              settings.okButtonCallback,
              (settings.closeButtonCallback === null) ? settings.okButtonCallback : settings.closeButtonCallback);
        });

    };

    return function(config, element){
        $(element).subscribeWidget();
    };
});