<?php

namespace Pinamondo\Seotext\Api\Data;

interface PostInterface
{
    /**
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ID                    = 'id';
    const NAME                  = 'name';
    const TITLE_1               = 'title_1';
    const TEXT_1                = 'text_1';
    const TITLE_2               = 'title_2';
    const TEXT_2                = 'text_2';
    const TITLE_3               = 'title_3';
    const TEXT_3                = 'text_3';
    const ADVANCED_CSS          = 'advanced_css';
    const CREATED_AT            = 'created_at';

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get Name
     *
     * @return string
     */
    public function getName();

    /**
     * Get Title 1
     *
     * @return string
     */
    public function getTitle1();

    /**
     * Get Text 1
     *
     * @return string|null
     */
    public function getText1();

    /**
     * Get Title 2
     *
     * @return string
     */
    public function getTitle2();

    /**
     * Get Text 2
     *
     * @return string|null
     */
    public function getText2();

    /**
     * Get Title 3
     *
     * @return string
     */
    public function getTitle3();

    /**
     * Get Text 3
     *
     * @return string|null
     */
    public function getText3();

    /**
     * Get Advanced Css
     *
     * @return string|null
     */
    public function getAdvancedCss();

    /**
     * Get Created At
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Set ID
     *
     * @param int $id
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setId($id);

    /**
     * Set Name
     *
     * @param string $name
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setName($name);

    /**
     * Set Title 1
     *
     * @param string $title1
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setTitle1($title1);

    /**
     * Set Text 1
     *
     * @param string $text1
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setText1($text1);

    /**
     * Set Title 2
     *
     * @param string $title2
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setTitle2($title2);

    /**
     * Set Text 2
     *
     * @param string $text2
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setText2($text2);

    /**
     * Set Title 3
     *
     * @param string $title3
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setTitle3($title3);

    /**
     * Set Text 3
     *
     * @param string $text3
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setText3($text3);

    /**
     * Set Advanced Css
     *
     * @param string $advancedCss
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setAdvancedCss($advancedCss);

    /**
     * Set Created At
     *
     * @param string $createdAt
     * @return \Pinamondo\Seotext\Api\Data\PostInterface
     */
    public function setCreatedAt($createdAt);

}