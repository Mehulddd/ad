<?php

namespace Pinamondo\Seotext\Block\Adminhtml\Post\Edit;

/**
 * Adminhtml blog post edit form
 */
class Form extends \Magento\Backend\Block\Widget\Form\Generic
{

    /**
     * @var \Magento\Store\Model\System\Store
     */
    protected $_systemStore;

    /**
     * @param \Magento\Backend\Block\Template\Context $context
     * @param \Magento\Framework\Registry $registry
     * @param \Magento\Framework\Data\FormFactory $formFactory
     * @param \Magento\Cms\Model\Wysiwyg\Config $wysiwygConfig
     * @param \Magento\Store\Model\System\Store $systemStore
     * @param array $data
     */
    public function __construct(
        \Magento\Backend\Block\Template\Context $context,
        \Magento\Framework\Registry $registry,
        \Magento\Framework\Data\FormFactory $formFactory,
        \Magento\Store\Model\System\Store $systemStore,
        array $data = []
    ) {
        $this->_systemStore = $systemStore;
        parent::__construct($context, $registry, $formFactory, $data);
    }

    /**
     * Init form
     *
     * @return void
     */
    protected function _construct()
    {
        parent::_construct();
        $this->setId('post_form');
        $this->setTitle(__('Post Information'));
    }

    /**
     * Prepare form
     *
     * @return $this
     */
    protected function _prepareForm()
    {
        /** @var \Ashsmith\Blog\Model\Post $model */
        $model = $this->_coreRegistry->registry('blog_post');

        /** @var \Magento\Framework\Data\Form $form */
        $form = $this->_formFactory->create(
            ['data' => ['id' => 'edit_form', 'action' => $this->getData('action'), 'method' => 'post']]
        );

        $form->setHtmlIdPrefix('post_');

        $fieldset = $form->addFieldset(
            'base_fieldset',
            ['legend' => __('General Information'), 'class' => 'fieldset-wide']
        );

        if ($model->getId()) {
            $fieldset->addField('id', 'hidden', ['name' => 'id']);
        }

        $fieldset->addField(
            'name',
            'text',
            ['name' => 'name', 'label' => __('Name'), 'title' => __('Name'), 'required' => true]
        );

        $fieldset->addField(
            'advanced_css',
            'editor',
            [
                'name' => 'advanced_css',
                'label' => __('Advanced Css'),
                'title' => __('Advanced Css'),
                'style' => 'height:16em',
                'required' => false
            ]
        );

        $fieldset->addField(
            'title_1',
            'text',
            [
                'name' => 'title_1',
                'label' => __('Title 1'),
                'title' => __('Title 1'),
                'note' => __('<small>Use <i>{empty}</i> keyword to occupy space for the title on the page but to keep it empty</small>'),
                'required' => false
            ]
        );

        $fieldset->addField(
            'text_1',
            'editor',
            [
                'name' => 'text_1',
                'label' => __('Text 1'),
                'title' => __('Text 1'),
                'style' => 'height:26em',
                'required' => false
            ]
        );

        $fieldset->addField(
            'title_2',
            'text',
            [
                'name' => 'title_2',
                'label' => __('Title 2'),
                'title' => __('Title 2'),
                'note' => __('<small>Use <i>{empty}</i> keyword to occupy space for the title on the page but to keep it empty</small>'),
                'required' => false
            ]
        );

        $fieldset->addField(
            'text_2',
            'editor',
            [
                'name' => 'text_2',
                'label' => __('Text 2'),
                'title' => __('Text 2'),
                'style' => 'height:26em',
                'required' => false
            ]
        );

        $fieldset->addField(
            'title_3',
            'text',
            [
                'name' => 'title_3',
                'label' => __('Title 3'),
                'title' => __('Title 3'),
                'note' => __('<small>Use <i>{empty}</i> keyword to occupy space for the title on the page but to keep it empty</small>'),
                'required' => false
            ]
        );

        $fieldset->addField(
            'text_3',
            'editor',
            [
                'name' => 'text_3',
                'label' => __('Text 3'),
                'title' => __('Text 3'),
                'style' => 'height:26em',
                'required' => false
            ]
        );

        $form->setValues($model->getData());
        $form->setUseContainer(true);
        $this->setForm($form);

        return parent::_prepareForm();
    }
}