<?php
namespace Pinamondo\Seotext\Block\Widget;

class SeotextBox extends \Magento\Framework\View\Element\Template implements \Magento\Widget\Block\BlockInterface
{
    protected function _construct()
    {
        parent::_construct();

        $om = \Magento\Framework\App\ObjectManager::getInstance();

        $connection = $om->create('\Magento\Framework\App\ResourceConnection')
            ->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tblSalesOrder = $connection->getTableName('pinamondo_seotext');
        $result = $connection->fetchRow('SELECT advanced_css,title_1,text_1,title_2,text_2,title_3,text_3 FROM `'.$tblSalesOrder.'` WHERE id='.$this->getData('seotextid'));

        $this->setData('title_1', (strtolower(trim($result['title_1'])) === '{empty}') ? '&nbsp;' : $result['title_1']);
        $this->setData('title_2', (strtolower(trim($result['title_2'])) === '{empty}') ? '&nbsp;' : $result['title_2']);
        $this->setData('title_3', (strtolower(trim($result['title_3'])) === '{empty}') ? '&nbsp;' : $result['title_3']);

        $this->setData('text_1', $result['text_1']);
        $this->setData('text_2', $result['text_2']);
        $this->setData('text_3', $result['text_3']);
        $this->setData('css', preg_replace("%'%", "\\'", $result['advanced_css']));

        $this->setTemplate('widget/seotextbox.phtml');
    }
}