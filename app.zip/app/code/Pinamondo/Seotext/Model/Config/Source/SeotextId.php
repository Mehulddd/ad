<?php

namespace Pinamondo\Seotext\Model\Config\Source;

class SeotextId implements \Magento\Framework\Option\ArrayInterface
{

    public function toOptionArray()
    {
        $om = \Magento\Framework\App\ObjectManager::getInstance();

        $connection = $om->create('\Magento\Framework\App\ResourceConnection')
            ->getConnection(\Magento\Framework\App\ResourceConnection::DEFAULT_CONNECTION);

        $tblSalesOrder = $connection->getTableName('pinamondo_seotext');
        $results = $connection->fetchAll('SELECT id, name FROM `'.$tblSalesOrder.'`');

        foreach($results as $result) {
            $fl['label'] = __($result['name']);
            $fl['value'] = $result['id'];
            $list[] = $fl;
        }

        return $list;
    }
}