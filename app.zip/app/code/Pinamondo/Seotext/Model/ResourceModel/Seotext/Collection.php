<?php

namespace Pinamondo\Seotext\Model\ResourceModel\Affiliate;

class Collection extends \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection
{

    /**
     * Define resource model
     *
     * @return void
     */
    protected function _construct()
    {
        $this->_init('Pinamondo\Seotext\Model\Seotext', 'Pinamondo\Seotext\Model\ResourceModel\Seotext');
    }
}