------------

Installation
------------

Run the following to check if module is listed

    ./bin/magento module:status

List of disabled modules:
Pinamondo_Seotext

Run to enable module

    ./bin/magento module:enable Pinamondo_Seotext

The following modules have been enabled:
- Pinamondo_Seotext


Run upgrade to install db schema

    ./bin/magento setup:upgrade
