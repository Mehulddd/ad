<?php

namespace Pinamondo\Seotext\Setup;

use Magento\Framework\Setup\InstallSchemaInterface;
use Magento\Framework\Setup\ModuleContextInterface;
use Magento\Framework\Setup\SchemaSetupInterface;
use Magento\Framework\DB\Ddl\Table;

class InstallSchema implements InstallSchemaInterface
{
    /**
     * Installs DB schema for a module
     *
     * @param SchemaSetupInterface $setup
     * @param ModuleContextInterface $context
     * @return void
     */
    public function install(SchemaSetupInterface $setup, ModuleContextInterface $context)
    {
        $installer = $setup;

        $installer->startSetup();

        $table = $installer->getConnection()
            ->newTable($installer->getTable('pinamondo_seotext'))
            ->addColumn('id', Table::TYPE_INTEGER, null, ['identity' => true, 'nullable' => false, 'primary' => true])
            ->addColumn('title_1', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('text_1', Table::TYPE_TEXT, '2M', ['nullable' => true, 'default' => null])
            ->addColumn('title_2', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('text_2', Table::TYPE_TEXT, '2M', ['nullable' => true, 'default' => null])
            ->addColumn('title_3', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('text_3', Table::TYPE_TEXT, '2M', ['nullable' => true, 'default' => null])
            ->addColumn('advanced_css', Table::TYPE_TEXT, 255, ['nullable' => true, 'default' => null])
            ->addColumn('created_at', Table::TYPE_DATETIME, null, ['nullable' => false])
            ->setComment('Pinamondo Seotext');

        $installer->getConnection()->createTable($table);

        $installer->endSetup();
    }
}