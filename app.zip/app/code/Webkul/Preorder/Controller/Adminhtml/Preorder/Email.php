<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Controller\Adminhtml\Preorder;

use Magento\Backend\App\Action;
use Webkul\Preorder\Model\ResourceModel\Preorder\CollectionFactory as PreorderCollection;

class Email extends \Magento\Backend\App\Action
{
    /**
    * @var \Webkul\Preorder\Helper\Data
    */
    protected $_preorderHelper;

    /**
    * @var PreorderCollection
    */
    protected $_preorderCollection;

    /**
    * @param Action\Context $context
    * @param \Webkul\Preorder\Helper\Data $preorderHelper
    * @param PreorderCollection $preorderCollection
    */
    public function __construct(
        Action\Context $context,
        \Webkul\Preorder\Helper\Data $preorderHelper,
        PreorderCollection $preorderCollection
    )
    {
        $this->_preorderHelper = $preorderHelper;
        $this->_preorderCollection = $preorderCollection;
        parent::__construct($context);
    }

    /**
    * {@inheritdoc}
    */
    protected function _isAllowed()
    {
        return $this->_authorization->isAllowed('Webkul_Preorder::preorder');
    }

    /**
     * @return \Magento\Framework\Controller\ResultInterface
    */
    public function execute()
    {
        $helper = $this->_preorderHelper;
        $info = [];
        $data = $this->getRequest()->getParams();
        $orderIds = $data['preorder'];
        $model = $this->_objectManager->create('Webkul\Preorder\Model\Preorder');
        $collection = $this->_preorderCollection
                            ->create()
                            ->addFieldToFilter("order_id", ['in' => $orderIds]);

        $collection->getSelect()->reset('columns')
                                ->columns('product_id')
                                ->columns('customer_email');
        foreach ($collection as $item) {
            $info[] = $item->getProductId();
        }
        foreach ($info as $productId) {
            $stockDetails = $helper->getStockDetails($productId);
            if ($stockDetails['is_in_stock'] == 1) {
                $emailIds = $helper->getCustomerEmailIds($productId);
                $ids = $helper->getCustomerIds($productId);
                $helper->sendNotifyEmail($emailIds, $stockDetails['name']);
            }
        }
        $this->messageManager->addSuccess(__('Email sent succesfully.'));
        $resultRedirect = $this->resultRedirectFactory->create();
        return $resultRedirect->setPath('*/*/');
    }

}