<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Controller\Preorder;

use Magento\Framework\App\Action\Action;
use Magento\Framework\App\Action\Context;
use Magento\Framework\View\Result\PageFactory;

class Check extends \Magento\Framework\App\Action\Action
{
    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    protected $_configurable;

    /**
     * @var \Webkul\Preorder\Helper\Data
     */
    protected $_preorderHelper;

    /**
     * @param Context $context
     * @param \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable
     * @param \Webkul\Preorder\Helper\Data $preorderHelper
     */
    public function __construct(
        Context $context,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable,
        \Webkul\Preorder\Helper\Data $preorderHelper
    )
    {
        $this->_configurable = $configurable;
        $this->_preorderHelper = $preorderHelper;
        parent::__construct($context);
    }

    /**
     * @return \Magento\Framework\Controller\Result\Redirect|\Magento\Framework\View\Result\Page
     */
    public function execute()
    {
        $info = [];
        $helper = $this->_preorderHelper;
        $type = $this->getRequest()->getParam('type');
        $productId = $this->getRequest()->getParam('product_id');
        if ($type == 1) {
            $attributesInfo = $this->getRequest()->getParam('info');
            $product = $helper->getProduct($productId);
            $configModel = $this->_configurable;
            $usedProduct = $configModel->getProductByAttributes($attributesInfo, $product);
            $productId = $usedProduct->getId();
        }
        if ($helper->isPreorder($productId)) {
            $payHtml = $helper->getPayPreOrderHtml();
            $msg = $helper->getPreOrderInfoBlock($productId);
            $info['preorder'] = 1;
            $info['msg'] = $msg;
            $info['payHtml'] = $payHtml;
        } else {
            $info['preorder'] = 0;
        }
        echo json_encode($info);
        die;
    }

}