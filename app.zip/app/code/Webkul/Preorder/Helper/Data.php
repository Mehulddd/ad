<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Helper;

use Magento\Framework\App\Filesystem\DirectoryList;
use Magento\Framework\App\Area;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollection;
use Webkul\Preorder\Model\ResourceModel\Item\CollectionFactory as ItemCollection;
use Webkul\Preorder\Model\ResourceModel\Preorder\CollectionFactory as PreorderCollection;

class Data extends \Magento\Framework\App\Helper\AbstractHelper
{
    /**
     * @var \Magento\Framework\App\RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Framework\UrlInterface
     */
    protected $_urlBuilder;

    /**
     * @var \Magento\Framework\App\Config\ScopeConfigInterface
     */
    protected $_scopeConfig;

    /**
     * @var \Magento\Framework\App\ResourceConnection
     */
    protected $_resource;

    /**
     * @var \Magento\Framework\Filesystem
     */
    protected $_filesystem;

    /**
     * @var \Magento\Store\Model\StoreManagerInterface
     */
    protected $_storeManager;

    /**
     * @var \Magento\Framework\Mail\Template\TransportBuilder
     */
    protected $_transportBuilder;

    /**
     * @var \Magento\Framework\Translate\Inline\StateInterface
     */
    protected $_inlineTranslation;

    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    protected $_configurable;

    /**
     * @var \Magento\Catalog\Model\ProductFactor
     */
    protected $_product;

    /**
     * @var \Magento\Sales\Model\OrderFactory
     */
    protected $_order;

    /**
     * @var \Magento\Catalog\Model\Product\Option
     */
    protected $_option;

    /**
     * @var ProductCollection
     */
    protected $_productCollection;

    /**
     * @var ItemCollection
     */
    protected $_itemCollection;

    /**
     * @var PreorderCollection
     */
    protected $_preorderCollection;

    /**
     * @param \Magento\Framework\App\Helper\Context $context
     * @param \Magento\Framework\App\ResourceConnection $resource
     * @param \Magento\Framework\Filesystem $filesystem
     * @param \Magento\Store\Model\StoreManagerInterface $storeManager
     * @param \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder
     * @param \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation
     * @param \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable
     * @param \Magento\Catalog\Model\ProductFactory $product
     * @param \Magento\Sales\Model\OrderFactory $order
     * @param \Magento\Catalog\Model\Product\Option $option
     * @param ProductCollection $productCollection
     * @param ItemCollection $itemCollection
     * @param PreorderCollection $preorderCollection
     * 
     * @param 
     */
    public function __construct(
        \Magento\Framework\App\Helper\Context $context,
        \Magento\Framework\App\ResourceConnection $resource,
        \Magento\Framework\Filesystem $filesystem,
        \Magento\Store\Model\StoreManagerInterface $storeManager,
        \Magento\Framework\Mail\Template\TransportBuilder $transportBuilder,
        \Magento\Framework\Translate\Inline\StateInterface $inlineTranslation,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable,
        \Magento\Catalog\Model\ProductFactory $product,
        \Magento\Sales\Model\OrderFactory $order,
        \Magento\Catalog\Model\Product\Option $option,
        ProductCollection $productCollection,
        ItemCollection $itemCollection,
        PreorderCollection $preorderCollection
    )
    {
        $this->_request = $context->getRequest();
        $this->_urlBuilder = $context->getUrlBuilder();
        $this->_scopeConfig = $context->getScopeConfig();
        $this->_resource = $resource;
        $this->_filesystem = $filesystem;
        $this->_storeManager = $storeManager;
        $this->_transportBuilder = $transportBuilder;
        $this->_inlineTranslation = $inlineTranslation;
        $this->_configurable = $configurable;
        $this->_product = $product;
        $this->_order = $order;
        $this->_option = $option;
        $this->_productCollection = $productCollection;
        $this->_itemCollection = $itemCollection;
        $this->_preorderCollection = $preorderCollection;
        parent::__construct($context);
    }

    /**
     * Get Preorder Type
     *  
     * @return int
     */
    public function getPreorderType()
    {
        return $this->_scopeConfig->getValue('preorder/settings/preorder_type');
    }

    /**
     * Get Preorder Percent
     *  
     * @return int
     */
    public function getPreorderPercent()
    {
        return $this->_scopeConfig->getValue('preorder/settings/preorder_percent');
    }

    /**
     * Get Admin Email Id
     *  
     * @return string
     */
    public function getAdminEmail()
    {
        return trim($this->_scopeConfig->getValue('preorder/settings/preorder_email'));
    }

    /**
     * Get Auto Email Configuration
     *  
     * @return bool
     */
    public function getAutoEmail()
    {
        return $this->_scopeConfig->getValue('preorder/settings/preorder_email_type');
    }

    /**
     * Get Stock Status of Product
     *
     * @param int $productId
     * 
     * @return bool
     */
    public function getStockStatus($productId)
    {
        $stockDetails = $this->getStockDetails($productId);
        return $stockDetails['is_in_stock'];
    }

    /**
     * Check Product is Preorder or Not
     *
     * @param int  $productId
     * @param bool $stockStatus [optional]
     * 
     * @return bool
     */
    public function isPreorder($productId, $stockStatus = '')
    {
        $isProduct = false;
        $preorderCompleteProductId = $this->getPreorderCompleteProductId();
        $productId = (int) $productId;
        if ($productId == $preorderCompleteProductId) {
            return 0;
        }
        if ($productId == '' || $productId == 0) {
            return 0;
        }
        $collection = $this->_productCollection->create();
        $collection->addFieldToFilter('entity_id', $productId);
        $collection->addAttributeToSelect('*');
        foreach ($collection as $item) {
            $product = $item;
            $isProduct = true;
            break;
        }
        if (!$isProduct) {
            return false;
        }
        $productType = $product->getTypeId();
        $productTypeArray = ['configurable', 'bundle', 'grouped'];
        if (in_array($productType, $productTypeArray)) {
            return 0;
        }
        if ($stockStatus == '') {
            $stockStatus = $this->getStockStatus($productId);
        }
        if (!$stockStatus) {
            $preorderStatus = $product->getWkPreorder();
            return $preorderStatus;
        }
        return 0;
    }

    /**
     * Check Configurable Product is Preorder or Not
     *
     * @param int $productId
     * 
     * @return bool
     */
    public function isConfigPreorder($productId, $stockStatus = '')
    {
        $isProduct = false;
        $collection = $this->_productCollection->create();
        $collection->addFieldToFilter('entity_id', $productId);
        $collection->addAttributeToSelect('*');
        foreach ($collection as $item) {
            $product = $item;
            $isProduct = true;
            break;
        }
        if ($isProduct) {
            $productType = $product->getTypeId();
            if ($productType == 'configurable') {
                $configModel = $this->_configurable;
                $usedProductIds = $configModel->getUsedProductIds($product);
                foreach ($usedProductIds as $usedProductId) {
                    if ($stockStatus != '') {
                        if ($this->isPreorder($usedProductId, $stockStatus)) {
                            return true;
                        }
                    } else {
                        if ($this->isPreorder($usedProductId)) {
                            return true;
                        }
                    }
                }
            }
        }
        return false;
    }

    /**
     * Get Mediad Path
     * 
     * @return string
     */
    public function getMediaPath()
    {
        return $this->_filesystem
                    ->getDirectoryRead(DirectoryList::MEDIA)
                    ->getAbsolutePath();
    }
    /**
     * Check Product is Partial Preorder or Not
     *
     * @param int $productId
     * 
     * @return bool
     */
    public function isPartialPreorder($productId)
    {
        if (!$this->isPreorder($productId)) {
            return false;
        }
        $preorderType = $this->getPreorderType();
        if ($preorderType == 1) {
            return true;
        }
        return false;
    }

    /**
     * Get Product's Price
     *
     * @param int $productId
     * 
     * @return float
     */
    public function getPrice($product)
    {
        $price = $product->getFinalPrice();
        return $price;
    }

    /**
     * Get Partial Preorder Price
     *
     * @param object $product
     * @param int $productId
     * 
     * @return flaot
     */
    public function getPreorderPrice($product, $productId)
    {
        $price = $this->getPrice($product, $productId);
        if ($this->isPartialPreorder($productId)) {
            $preorderPercent = (int) $this->getPreorderPercent();
            if ($preorderPercent > 0) {
                $price = ($price * $preorderPercent) / 100;
            }
        }
        return $price;
    }

    /**
     * Get Order by Id
     *
     * @param int $orderId
     * 
     * @return object
     */
    public function getOrder($orderId)
    {
        return $this->_order->create()->load($orderId);
    }

    /**
     * Check Order Item is Preorder or Not
     *
     * @param int $itemId
     * 
     * @return bool
     */
    public function isPreorderOrderedItem($itemId)
    {
        $id = 0;
        $collection = $this->_itemCollection
                            ->create()
                            ->addFieldToFilter('item_id', $itemId);
        foreach ($collection as $value) {
            $id = $value->getId();
            break;
        }
        if ($id == 0) {
            return false;
        }
        return true;
    }

    /**
     * Get Preorder Status
     *
     * @param int $itemId
     * 
     * @return int
     */
    public function getPreorderStatus($itemId)
    {
        $status = 0;
        $model = $this->_preorderCollection->create();
        $collection = $this->_preorderCollection
                            ->create()
                            ->addFieldToFilter('item_id', $itemId);
        foreach ($collection as $value) {
            $status = $value->getStatus() + 1;
            break;
        }
        return $status;
    }

    /**
     * Check Product is Child Product or Not
     * 
     * @return bool
     */
    public function isChildProduct()
    {
        $productId = $this->_request->getParam('id');
        $productModel = $this->_product->create();
        $product = $productModel->load($productId);
        $productType = $product->getTypeID();
        $productTypeArray = ['bundle', 'grouped'];
        if (in_array($productType, $productTypeArray)) {
            return true;
        }
        return false;
    }

    /**
     * Check Preorder Option is Allowed for Product Type
     * 
     * @return bool
     */
    public function showPreorderOption()
    {
        $productId = $this->_request->getParam('id');
        $productModel = $this->_product->create();
        $product = $productModel->load($productId);
        $productType = $product->getTypeID();
        $productTypeArray = ['configurable', 'bundle', 'grouped'];
        if (in_array($productType, $productTypeArray)) {
            return 0;
        }
        return 1;
    }

    /**
     * Get Url To Check Configurable Product is Preorder or Not
     * 
     * @return string
     */
    public function getCheckConfigUrl()
    {
        return $this->_urlBuilder->getUrl('preorder/preorder/check/');
    }

    /**
     * Get Url To Complete Preorder Order
     * 
     * @return string
     */
    public function getCompletePreorderUrl()
    {
        return $this->_urlBuilder->getUrl('preorder/preorder/complete/');
    }

    /**
     * Get Account Login Url For Customer
     * 
     * @return string
     */
    public function getLogInUrl()
    {
        return $this->_urlBuilder->getUrl('customer/account/login/');
    }

    /**
     * Get Product by Id
     *
     * @param int $productId
     * 
     * @return object
     */
    public function getProduct($productId)
    {
        return $this->_product->create()->load($productId);
    }

    /**
     * Get Prorder Complete Product Id
     * 
     * @return int
     */
    public function getPreorderCompleteProductId()
    {
        $productModel = $this->_product->create();
        $productId = (int) $productModel->getIdBySku('preorder_complete');
        return $productId;
    }

    /**
     * Get Preorder Complete Product's Options
     * 
     * @return json
     */
    public function getPreorderCompleteOptions()
    {
        $array = [];
        $productId = (int) $this->getPreorderCompleteProductId();
        $product = $this->_product->create()->load($productId);
        foreach ($product->getOptions() as $option) {
            $optionId = $option->getId();
            $optionTitle = $option->getTitle();
            $array[] = ['id' => $optionId, 'title' => $optionTitle];
        }
        return json_encode($array);
    }

    /**
     * Get Html Block of Pay Preorder Amount (Partial Preorder)
     * 
     * @return html
     */
    public function getPayPreOrderHtml()
    {
        $html = '';
        $type = $this->getPreorderType();
        $percent = (int) $this->getPreorderPercent();
        if ($type == 1 && $percent > 0) {
            $html .= "<div class='wk-msg-box wk-info wk-pay-preorer-amount'>";
            $html .= __('Pay %1% as Preorder.', $percent);
            $html .= '</div>';
        }
        return $html;
    }

    /**
     * Get Stock Details of Product
     *
     * @param int $productId
     * 
     * @return array
     */
    public function getStockDetails($productId)
    {
        $connection = $this->_resource->getConnection();
        $stockDetails = ['is_in_stock' => 0, 'qty' => 0];
        $collection = $this->_productCollection->create()->addAttributeToSelect('name');
        $tableName = $connection->getTableName('cataloginventory_stock_item');
        $bind = 'product_id = entity_id';
        $cond = '{{table}}.stock_id = 1';
        $joinType = 'left';
        $alias = 'is_in_stock';
        $field = 'is_in_stock';
        $collection->joinField($alias, $tableName, $field, $bind, $cond, $joinType);
        $alias = 'qty';
        $field = 'qty';
        $collection->joinField($alias, $tableName, $field, $bind, $cond, $joinType);
        $collection->addFieldToFilter('entity_id', $productId);
        foreach ($collection as $value) {
            $stockDetails['qty'] = $value->getQty();
            $stockDetails['is_in_stock'] = $value->getIsInStock();
            $stockDetails['name'] = $value->getName();
        }
        return $stockDetails;
    }

    /**
     * Check Product is Available or Not to Complete Preorder
     *
     * @param int $productId
     * @param int $qty
     * @param int $isQty
     * 
     * @return bool
     */
    public function isAvailable($productId, $qty, $isQty = 0)
    {
        $stockDetails = $this->getStockDetails($productId);
        if ($stockDetails['is_in_stock'] == 1) {
            if ($isQty == 0) {
                if ($stockDetails['qty'] > $qty) {
                    return true;
                }
            } else {
                return true;
            }
        }
        return false;
    }

    /**
     * Check if Configurable Product is Available or Not to Complete Preorder
     *
     * @param int $productId
     * @param int $qty
     * @param int $parentId
     * 
     * @return bool
     */
    public function isConfigAvailable($productId, $qty, $parentId)
    {
        if ($this->isAvailable($productId, $qty) && $this->isAvailable($parentId, $qty, 1)) {
            return true;
        }
        return false;
    }

    /**
     * Get Html Block of Preorder Info Block
     *
     * @param int $productId
     * 
     * @return html
     */
    public function getPreOrderInfoBlock($productId)
    {
        $html = '';
        $flag = 0;
        $today = date('l jS F Y');
        $t = strtotime($today);
        $product = $this->getProduct($productId);
        $availability = $product->getPreorderAvailability();
        if ($availability != '') {
            $date = date_create($availability);
            $date = date_format($date, 'l jS F Y');
            $d = strtotime($date);
            if ($d > $t) {
                $flag = 1;
            }
        }
        $msg = $this->_scopeConfig->getValue('preorder/settings/preorder_msg');
        $msg = str_replace("\n", '<br>', $msg);
        if ($msg != '') {
            $html .= "<div class='wk-msg-box wk-info'>";
            $html .= $msg;
            $html .= '</div>';
        }
        if ($flag == 1) {
            $html .= "<div class='wk-msg-box wk-info wk-availability-block'><span class='wk-date-title'>";
            $html .= __('Available On');
            $html .= ' :</span>';
            $html .= "<span class='wk-date'>".$date.'</span>';
            $html .= '</div>';
        }
        return $html;
    }

    /**
     * Get Customer Id's who Ordered Preorder Items
     *
     * @param int $productId
     * 
     * @return array
     */
    public function getCustomerIds($productId)
    {
        $emailIds = [];
        $collection = $this->_preorderCollection
                            ->create()
                            ->addFieldToFilter('product_id', $productId);
        $collection->getSelect()->reset('columns')->columns('customer_email');
        foreach ($collection as $value) {
            $emailIds[] = $value->getCustomerEmail();
        }
        $emailIds = array_unique($emailIds);
        return $emailIds;
    }

    /**
     * Get Email Id's of Customers who Ordered Preorder Items
     *
     * @param int $productId
     * 
     * @return array
     */
    public function getCustomerEmailIds($productId)
    {
        $emailIds = [];
        $collection = $this->_preorderCollection
                            ->create()
                            ->addFieldToFilter('product_id', $productId);
        $collection->getSelect()->reset('columns')->columns('customer_email');
        foreach ($collection as $value) {
            $emailIds[] = $value->getCustomerEmail();
        }
        $emailIds = array_unique($emailIds);
        return $emailIds;
    }

    /**
     * Send Notification Email when Product is in Stock
     *
     * @param array emailIds
     * @param string $productName
     */
    public function sendNotifyEmail($emailIds, $productName)
    {
        $adminEmail = $this->getAdminEmail();
        $loginUrl = $this->getLogInUrl();
        if ($adminEmail != '') {
            $msg = __('Product "%1" is in stock. Please go your account to complete preorder.', $productName);
            $templateOptions = ['area' => Area::AREA_FRONTEND, 'store' => $this->_storeManager->getStore()->getId()];
            $templateVars = [
                                'store' => $this->_storeManager->getStore(),
                                'message' => $msg,
                                'login_url' => $loginUrl,
                            ];
            $from = ['email' => $adminEmail, 'name' => 'Store Owner'];
            foreach ($emailIds as $emailId) {
                $templateVars['customer_name'] = '';
                $this->_inlineTranslation->suspend();
                $to = [$emailId];
                $transport = $this->_transportBuilder->setTemplateIdentifier('in_stock_notify')
                                ->setTemplateOptions($templateOptions)
                                ->setTemplateVars($templateVars)
                                ->setFrom($from)
                                ->addTo($to)
                                ->getTransport();
                $transport->sendMessage();
                $this->_inlineTranslation->resume();
            }
        }
    }

    /**
     * Create Preorder Complete Product if Not Exists
     */
    public function createPreOrderProduct()
    {
        $preorderProductId = $this->getPreorderCompleteProductId();
        if ($preorderProductId == 0 || $preorderProductId == '') {
            $websiteIds = $this->getWebsiteIds();
            $stockData = [
                            'use_config_manage_stock' => 0,
                            'manage_stock' => 0,
                            'is_in_stock' => 1,
                            'qty' => 999999999,
                        ];
            $preorderProduct = $this->_product->create();
            $preorderProduct->setSku('preorder_complete');
            $preorderProduct->setName('Complete PreOrder');
            $preorderProduct->setAttributeSetId(4);
            $preorderProduct->setCategoryIds([2]);
            $preorderProduct->setWebsiteIds($websiteIds);
            $preorderProduct->setStatus(1);
            $preorderProduct->setVisibility(1);
            $preorderProduct->setTaxClassId(0);
            $preorderProduct->setTypeId('virtual');
            $preorderProduct->setPrice(0);
            $preorderProduct->setStockData($stockData);
            $preorderProduct->save();
            $path = $this->getMediaPath().'preorder/images/preorder.png';
            if (file_exists($path)) {
                $types = ['image', 'small_image', 'thumbnail'];
                $preorderProduct->addImageToMediaGallery($path, $types, false, false);
            }
            $preorderProduct->save();
            $option1 = [
                            'sort_order' => 1,
                            'title' => 'Product Name',
                            'price_type' => 'fixed',
                            'price' => '',
                            'type' => 'field',
                            'is_require' => 0,
                        ];
            $option2 = [
                            'sort_order' => 2,
                            'title' => 'Order Refernce',
                            'price_type' => 'fixed',
                            'price' => '',
                            'type' => 'field',
                            'is_require' => 0,
                        ];

            $options = [$option1, $option2];
            foreach ($options as $arrayOption) {
                $preorderProduct->setHasOptions(1);
                $preorderProduct->getResource()->save($preorderProduct);
                $option = $this->_option
                                ->setProductId($preorderProduct->getId())
                                ->setStoreId($preorderProduct->getStoreId())
                                ->addData($arrayOption);
                $option->save();
                $preorderProduct->addOption($option);
            }
        }
    }

    /**
     * Get All Website Ids
     * 
     * @return array
     */
    public function getWebsiteIds()
    {
        $websiteIds = [];
        $websites = $this->_storeManager->getWebsites();
        foreach ($websites as $website) {
            $websiteIds[] = $website->getId();
        }
        return $websiteIds;
    }
}