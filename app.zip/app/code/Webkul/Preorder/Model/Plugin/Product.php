<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Model\Plugin;

class Product
{
    public function afterIsSalable(\Magento\Catalog\Model\Product $subject, $result)
    {
        $productId = $subject->getId();
        $helper = $this->helper();
        if ($helper->isPreorder($productId) && !$helper->isChildProduct()) {
            return true;
        } elseif ($helper->isConfigPreorder($productId)) {
            return true;
        }
        return $result;
    }

    public function helper()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $helper = $objectManager->create('Webkul\Preorder\Helper\Data');
        return $helper;
    }
}