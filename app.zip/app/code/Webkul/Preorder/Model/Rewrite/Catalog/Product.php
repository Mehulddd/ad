<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Model\Rewrite\Catalog;

class Product extends \Magento\Catalog\Model\Product
{
    public function isSalable()
    {
        $helper = $this->helper();
        if ($helper->isPreorder($this->getId()) && !$helper->isChildProduct()) {
            return true;
        } elseif ($helper->isConfigPreorder($this->getId())) {
            return true;
        } else {
            $this->_eventManager->dispatch('catalog_product_is_salable_before', ['product' => $this]);
            $salable = $this->isAvailable();
            $object = new \Magento\Framework\DataObject(['product' => $this, 'is_salable' => $salable]);
            $this->_eventManager->dispatch(
                'catalog_product_is_salable_after',
                ['product' => $this, 'salable' => $object]
            );
            return $object->getIsSalable();
        }
    }

    public function helper()
    {
        $objectManager = \Magento\Framework\App\ObjectManager::getInstance();
        $helper = $objectManager->create('Webkul\Preorder\Helper\Data');
        return $helper;
    }
}