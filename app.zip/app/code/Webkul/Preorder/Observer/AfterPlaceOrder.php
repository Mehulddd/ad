<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Webkul\Preorder\Model\ResourceModel\Item\CollectionFactory as ItemCollection;
use Webkul\Preorder\Model\ResourceModel\Complete\CollectionFactory as CompleteCollection;
use Webkul\Preorder\Model\ResourceModel\Preorder\CollectionFactory as PreorderCollection;

class AfterPlaceOrder implements ObserverInterface
{
    /**
     * @var \Webkul\Preorder\Helper\Data
     */
    protected $_preorderHelper;

    /**
     * @var \Webkul\Preorder\Model\PreorderFactory
     */
    protected $_preorder;

    /**
     * @var ItemCollection
     */
    protected $_itemCollection;

    /**
     * @var CompleteCollection
     */
    protected $_completeCollection;

    /**
     * @var PreorderCollection
     */
    protected $_preorderCollection;
    
    /**
     * @param \Webkul\Preorder\Helper\Data $preorderHelper
     * @param \Webkul\Preorder\Model\PreorderFactory $preorder
     * @param ItemCollection $itemCollection
     * @param CompleteCollection $completeCollection
     * @param PreorderCollection $preorderCollection
     */
    public function __construct(
        \Webkul\Preorder\Helper\Data $preorderHelper,
        \Webkul\Preorder\Model\PreorderFactory $preorder,
        ItemCollection $itemCollection,
        CompleteCollection $completeCollection,
        PreorderCollection $preorderCollection
    )
    {
        $this->_preorderHelper = $preorderHelper;
        $this->_preorder = $preorder;
        $this->_itemCollection = $itemCollection;
        $this->_completeCollection = $completeCollection;
        $this->_preorderCollection = $preorderCollection;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $helper = $this->_preorderHelper;
        $preorderType = $helper->getPreorderType();
        $orderIds = $observer->getEvent()->getData('order_ids');
        $orderId = $orderIds[0];
        $order = $helper->getOrder($orderId);
        $time = time();
        $customerId = (int) $order->getCustomerId();
        $customerEmail = $order->getCustomerEmail();
        $orderedItems = $order->getAllItems();
        foreach ($orderedItems as $item) {
            $remainingAmount = 0;
            $preorderPercent = "";
            $parentItem = ( $item->getParentItem() ? $item->getParentItem() : $item );
            $parentId = $parentItem->getProductId();
            $productId = $item->getProductId();
            $quoteItemId = $item->getQuoteItemId();
            if ($parentId == $productId) {
                $parentId = 0;
            }
            if ($helper->isPreorder($productId)) {
                $orderItemId = $item->getId();
                $parentItemId = $item->getParentItemId();
                $qty = $item->getQtyOrdered();
                $price = $parentItem->getPrice();
                if ($helper->isPartialPreorder($productId)) {
                    $collection = $this->_itemCollection
                                        ->create()
                                        ->addFieldToFilter("item_id", $quoteItemId);
                    foreach ($collection as $value) {
                        $id = $value->getId();
                        $preorderPercent = $value->getPreorderPercent();
                        break;
                    }
                    if ($preorderPercent != "" ) {
                        $totalPrice = ($price*100)/$preorderPercent;
                        $remainingAmount = $totalPrice- $price;
                    }
                }
                $preorderItemData = [
                                        'order_id'          =>  $orderId,
                                        'item_id'           =>  $orderItemId,
                                        'product_id'        =>  $productId,
                                        'parent_id'         =>  $parentId,
                                        'customer_id'       =>  $customerId,
                                        'customer_email'    =>  $customerEmail,
                                        'preorder_percent'  =>  $preorderPercent,
                                        'paid_amount'       =>  $price,
                                        'remaining_amount'  =>  $remainingAmount,
                                        'qty'               =>  $qty,
                                        'type'              =>  $preorderType,
                                        'status'            =>  0,
                                        'time'              =>  $time
                                    ];
                $this->_preorder->create()->setData($preorderItemData)->save();
            }
            $preorderCompleteProductId = $helper->getPreorderCompleteProductId();
            if ($productId == $preorderCompleteProductId) {
                $id = 0;
                $collection = $this->_completeCollection
                                        ->create()
                                        ->addFieldToFilter("quote_item_id", $quoteItemId);
                $collection->getSelect()->reset('columns')->columns('order_item_id');
                foreach ($collection as $value) {
                    $id = $value->getOrderItemId();
                    break;
                }
                $collection = $this->_preorderCollection
                                    ->create()
                                    ->addFieldToFilter("item_id", $id);
                foreach ($collection as $value) {
                    $id = $value->getId();
                    $remainingAmount = $value->getRemainingAmount();
                    $paidAmount = $value->getPaidAmount();
                    $totalAmount = $paidAmount+$remainingAmount;
                    $value->setStatus(1)
                            ->setRemainingAmount(0)
                            ->setPaidAmount($totalAmount)
                            ->setId($id)
                            ->save();
                    break;
                }
            }
        }
    }

}