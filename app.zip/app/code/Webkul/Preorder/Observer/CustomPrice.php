<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Webkul\Preorder\Model\ResourceModel\Item\CollectionFactory as ItemCollection;
use Webkul\Preorder\Model\ResourceModel\Preorder\CollectionFactory as PreorderCollection;
use Magento\Catalog\Model\ResourceModel\Product\CollectionFactory as ProductCollection;

class CustomPrice implements ObserverInterface
{
    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Customer\Model\Session
     */
    protected $_customerSession;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var \Magento\ConfigurableProduct\Model\Product\Type\Configurable
     */
    protected $_configurable;

    /**
     * @var \Webkul\Preorder\Model\ItemFactory
     */
    protected $_item;

    /**
     * @var \Webkul\Preorder\Helper\Data
     */
    protected $_preorderHelper;

    /**
     * @var ItemCollection
     */
    protected $_itemCollection;

    /**
     * @var PreorderCollection
     */
    protected $_preorderCollection;

    /**
     * @var ProductCollection
     */
    protected $_productCollection;
    
    /**
     * @param RequestInterface $request
     * @param \Magento\Customer\Model\Session $customerSession
     * @param \Magento\Framework\Message\ManagerInterface $messageManager
     * @param \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable
     * @param \Webkul\Preorder\Model\ItemFactory $item
     * @param \Webkul\Preorder\Helper\Data $preorderHelper
     * @param ItemCollection $itemCollection
     * @param PreorderCollection $preorderCollection
     * @param ProductCollection $productCollection
     */
    public function __construct(
        RequestInterface $request,
        \Magento\Customer\Model\Session $customerSession,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\ConfigurableProduct\Model\Product\Type\Configurable $configurable,
        \Webkul\Preorder\Model\ItemFactory $item,
        \Webkul\Preorder\Helper\Data $preorderHelper,
        ItemCollection $itemCollection,
        PreorderCollection $preorderCollection,
        ProductCollection $productCollection
    )
    {
        $this->_request = $request;
        $this->_customerSession = $customerSession;
        $this->_messageManager = $messageManager;
        $this->_configurable = $configurable;
        $this->_item = $item;
        $this->_preorderHelper = $preorderHelper;
        $this->_itemCollection = $itemCollection;
        $this->_preorderCollection = $preorderCollection;
        $this->_productCollection = $productCollection;

    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $helper = $this->_preorderHelper;
        $item = $observer->getEvent()->getData('quote_item');
        $data = $this->_request->getParams();
        $product = $observer->getEvent()->getData('product');
        $productId = $product->getId();
        $preorderPercent = (int) $helper->getPreorderPercent();
        //<!-- Configurable product case
        if (array_key_exists('selected_configurable_option', $data)) {
            if ($data['selected_configurable_option'] != "") {
                $productId = $data['selected_configurable_option'];
            } else {
                if (array_key_exists('super_attribute', $data)) {
                    $configModel = $this->_configurable;
                    $usedProduct = $configModel->getProductByAttributes($data['super_attribute'], $product);
                    $productId = $usedProduct->getId();
                }
            }
        }
        //Configurable product case --!>
        $itemId = (int) $item->getId();
        if ($helper->isPartialPreorder($productId)) {
            $item = ( $item->getParentItem() ? $item->getParentItem() : $item );
            $price = $helper->getPreorderPrice($product, $productId);
            $item->setCustomPrice($price);
            $item->setOriginalCustomPrice($price);
            $item->getProduct()->setIsSuperMode(true);
            if ($itemId > 0) {
                $id = 0;
                $collection = $this->_itemCollection
                                    ->create()
                                    ->addFieldToFilter("item_id", $itemId);
                foreach ($collection as $value) {
                    $id = $value->getId();
                    break;
                }
                if ($id != 0) {
                    $data =  ['item_id' => $itemId, 'preorder_percent' => $preorderPercent];
                    $this->_item->create()->addData($data)->setId($id)->save();
                }
            }
        }
        $preorderCompleteProductId = $helper->getPreorderCompleteProductId();
        if ($productId == $preorderCompleteProductId) {
            $customerId = 0;
            if ($this->_customerSession->isLoggedIn()) {
                $customerId = (int) $this->_customerSession->getCustomerId();
            }
            if ($customerId == 0) {
                $this->_messageManager->addNotice(__("There was some error while processing your request."));
                exit();
            }
            $data = $this->_request->getParams();
            $qty = $data['qty'];
            $orderId = $data['order_id'];
            $orderItemId = $data['item_id'];
            $preorderProductId = $data['pro_id'];
            $stockStatus = 0;
            $preorderQty = 0;

            $collection = $this->_productCollection->create();
            // $tableName = $connection->getTableName('cataloginventory_stock_item');
            $tableName = 'cataloginventory_stock_item';
            $bind = 'product_id = entity_id';
            $cond = '{{table}}.stock_id = 1';
            $joinType = 'left';
            $alias = 'is_in_stock';
            $field = 'is_in_stock';
            $collection->joinField($alias, $tableName, $field, $bind, $cond, $joinType);
            $alias = 'qty';
            $field = 'qty';
            $collection->joinField($alias, $tableName, $field, $bind, $cond, $joinType);
            $collection->addFieldToFilter("entity_id", $preorderProductId);
            foreach ($collection as $value) {
                $stockStatus = $value->getIsInStock();
                $preorderQty = $value->getQty();
            }
            if ($stockStatus == 0 || $qty > $preorderQty) {
                $this->_messageManager->addNotice(__("Product is not available."));
                exit();
            }
            if ($itemId > 0) {
                $this->_messageManager->addNotice(__("Already added to cart."));
                exit();
            }

            $collection = $this->_preorderCollection
                                ->create()
                                ->addFieldToFilter("item_id", $orderItemId)
                                ->addFieldToFilter("order_id", $orderId);
            foreach ($collection as $key => $value) {
                $remainingAmount = $value->getRemainingAmount();
            }
            $unitPrice = $remainingAmount;
            $item->setCustomPrice($unitPrice);
            $item->setOriginalCustomPrice($unitPrice);
            $item->getProduct()->setIsSuperMode(true);
        }
    }

}