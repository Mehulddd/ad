<?php
/**
 * Webkul Software.
 *
 * @category  Webkul
 * @package   Webkul_Preorder
 * @author    Webkul
 * @copyright Copyright (c) 2010-2016 Webkul Software Private Limited (https://webkul.com)
 * @license   https://store.webkul.com/license.html
 */
namespace Webkul\Preorder\Observer;

use Magento\Framework\Event\ObserverInterface;
use Magento\Framework\App\RequestInterface;
use Webkul\Preorder\Model\ResourceModel\Complete\CollectionFactory as CompleteCollection;

class UpdateCart implements ObserverInterface
{
    /**
     * @var RequestInterface
     */
    protected $_request;

    /**
     * @var \Magento\Framework\Message\ManagerInterface
     */
    protected $_messageManager;

    /**
     * @var \Magento\Checkout\Model\CartFactory
     */
    protected $_cart;

    /**
     * @var CompleteCollection
     */
    protected $_completeCollection;

    /**
     * @param RequestInterface $request
     */
    public function __construct(
        RequestInterface $request,
        \Magento\Framework\Message\ManagerInterface $messageManager,
        \Magento\Checkout\Model\CartFactory $cart,
        CompleteCollection $completeCollection
    )
    {
        $this->_request = $request;
        $this->_messageManager = $messageManager;
        $this->_cart = $cart;
        $this->_completeCollection = $completeCollection;
    }

    public function execute(\Magento\Framework\Event\Observer $observer)
    {
        $data = $this->_request->getParams();
        $quote = $this->_cart->create()->getQuote();
        $error = 0;
        foreach ($quote->getAllItems() as $item) {
            $itemId = $item->getId();
            $finalQty = $item->getQty();
            $collection = $this->_completeCollection
                                ->create()
                                ->getCollection()
                                ->addFieldToFilter("quote_item_id", $itemId);
            $collection->getSelect()->reset('columns')->columns('quote_item_id')->columns('qty');
            foreach ($collection as $value) {
                $qty = $value->getQty();
                if ($finalQty != $qty) {
                    $item->setQty($qty);
                    $error = 1;
                }
            }
        }
        if ($error == 1) {
            $this->_messageManager->addNotice(__("You can not update the quantity of Complete PreOrder Product."));
            $quote->save();
        }
    }

}