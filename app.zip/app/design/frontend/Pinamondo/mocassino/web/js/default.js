jQuery(document).ready(function () {
    //Language Selection
    jQuery('.selected-lang').on('click', function () {
        jQuery(this).parents('.language-selection').find('ul').slideToggle('fast');
    });

    // Feacherbar close
    jQuery('.btn-close').on('click', function () {
        jQuery('body').find('.header-features').slideUp('fast');
    });

    // Teaser slider
    if (jQuery('.teaser-slider').length) {
        var teaserSlider = jQuery('.teaser-slider');
        teaserSlider.owlCarousel({
            items: 2,
            loop: true,
            smartSpeed: 500,
            autoplayTimeout: 6000,
            autoplay: true,
            responsive: {
                0: {
                    items: 1
                },
                520: {
                    items: 2
                }
            },
            onInitialize: function () {
                if (jQuery('.slider-init .slide').length === 1) {
                    this.settings.nav = false;
                    this.settings.loop = false;
                }
            }
        });
    }

    // Product slider list
    var productListSlider = jQuery('.product-list-slider');
    productListSlider.each(function () {
        productListSlider.owlCarousel({
            items: 1,
            smartSpeed: 500,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            autoplayTimeout: 6000,
            autoplay: true,
            nav: true,
            loop: true,
            navText: ['<i class="fa fa-chevron-left" aria-hidden="true"></i>', '<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
            onInitialize: function () {
                if (jQuery(this).find('.slide').length === 1) {
                    this.settings.nav = false;
                    this.settings.loop = false;
                }
            }
        });
        jQuery(this).find('.owl-nav div').unwrap();
    });

    // Mobile Navigation
    jQuery('.menu-trigger').on('click', function () {
        jQuery('body').toggleClass('menu-open');
    });

    // SelectBox
    jQuery('.selected-val').on('click', function () {
        jQuery(this).parent().toggleClass('open').find('ul').slideToggle('fast');
    });
    jQuery('.select-box li').on('click', function () {
        var curVal = jQuery(this).html();
        jQuery(this).parents('.select-box').removeClass('open').find('ul').slideUp('fast');
        jQuery(this).parents('.select-box').find('.selected-val').html(curVal);
    });

    //product-detail-trigger
    jQuery('.product-detail-trigger').on('click', function () {
        jQuery(this).parents('.product-list-block').toggleClass('open').find('.product-detail').slideToggle('fast');
    });
    
    // Accordion 
    jQuery('.product-accordion-block h2').on('click',function (){
        jQuery(this).parents('.product-accordion-block').toggleClass('open').find('.product-accordion-content').slideToggle('fast');
    })
});

jQuery(window).load(function () {
    jQuery('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: true,
        slideshow: false,
        itemWidth: 107,
        itemMargin: 14,
        asNavFor: '#slider'
    });

    jQuery('#slider').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: true,
        slideshow: false,
        sync: "#carousel",
        start: function (slider) {
            jQuery('body').removeClass('loading');
        }
    });
});