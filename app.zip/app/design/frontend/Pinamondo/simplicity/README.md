Pinamondo Simplicity theme
==========================

It doesn't have any parent theme, but in fact Magento/blank theme's content was copied into this theme.
That was done for easier development, because tracing all the layouts, templates and less-files was a nightmare
due to inheritance.

So for now all the common shit is located in the main theme module, and in the /lib.
Concrete module specific resources are in the appropriate modules.