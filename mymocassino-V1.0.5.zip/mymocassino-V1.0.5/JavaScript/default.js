$(document).ready(function () {
    //Language Selection
    $('.selected-lang').on('click', function () {
        $(this).parents('.language-selection').find('ul').slideToggle('fast');
    });

    // Feacherbar close
    $('.btn-close').on('click', function () {
        $(this).parents('.header-features').slideUp('fast');
    });

    // Teaser slider
    if ($('.teaser-slider').length) {
        var teaserSlider = $('.teaser-slider');
        teaserSlider.owlCarousel({
            items: 2,
            loop: true,
            smartSpeed: 500,
            autoplayTimeout: 6000,
            autoplay: true,
            responsive: {
                0: {
                    items: 1
                },
                520: {
                    items: 2
                }
            },
            onInitialize: function () {
                if ($('.slider-init .slide').length === 1) {
                    this.settings.nav = false;
                    this.settings.loop = false;
                }
            }
        });
    }

    // Product slider list
    var productListSlider = $('.product-list-slider');
    productListSlider.each(function () {
        productListSlider.owlCarousel({
            items: 1,
            smartSpeed: 500,
            animateIn: 'fadeIn',
            animateOut: 'fadeOut',
            autoplayTimeout: 6000,
            autoplay: true,
            nav: true,
            loop: true,
            navText: ['<i class="fa fa-chevron-left" aria-hidden="true"></i>', '<i class="fa fa-chevron-right" aria-hidden="true"></i>'],
            onInitialize: function () {
                if ($(this).find('.slide').length === 1) {
                    this.settings.nav = false;
                    this.settings.loop = false;
                }
            }
        });
        $(this).find('.owl-nav div').unwrap();
    });

    // Mobile Navigation
    $('.menu-trigger').on('click', function () {
        $('body').toggleClass('menu-open');
    });

    // SelectBox
    $('.selected-val').on('click', function () {
        $(this).parent().toggleClass('open').find('ul').slideToggle('fast');
    });
    $('.select-box li').on('click', function () {
        var curVal = $(this).html();
        $(this).parents('.select-box').removeClass('open').find('ul').slideUp('fast');
        $(this).parents('.select-box').find('.selected-val').html(curVal);
    });

    //product-detail-trigger
    $('.product-detail-trigger').on('click', function () {
        $(this).parents('.product-list-block').toggleClass('open').find('.product-detail').slideToggle('fast');
    });
    
    // Accordion 
    $('.product-accordion-block h2').on('click',function (){
        $(this).parents('.product-accordion-block').toggleClass('open').find('.product-accordion-content').slideToggle('fast');
    })
});

$(window).load(function () {
    $('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: true,
        slideshow: false,
        itemWidth: 107,
        itemMargin: 14,
        asNavFor: '#slider'
    });

    $('#slider').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: true,
        slideshow: false,
        sync: "#carousel",
        start: function (slider) {
            $('body').removeClass('loading');
        }
    });
});